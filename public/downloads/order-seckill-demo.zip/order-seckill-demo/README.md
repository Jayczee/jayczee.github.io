# order-seckill-demo

从 [order-demo](https://github.com/Jayczee/order-demo) 的订单、库存、支付、取消和对账模型扩展的秒杀实验。独立项目，沿用 `available + locked + sold = total` 的库存口径，把原内存模拟表换成真实 MySQL，增加 Redis 预占、Stream 消费和恢复流程。没有依赖或修改原项目的运行环境。

## 运行

需要 JDK 17+、Maven 3.9、Docker Compose v2、Python 3 和 OpenSSL。建议空闲内存至少 3 GiB，镜像首次下载需联网。本例固定 Spring Boot 3.5.16、MySQL 8.0.41、Redis 8.6.2；Redis、Nginx 的多架构镜像固定 digest。

在本项目根目录依次执行：

```bash
bash scripts/init-secrets.sh
mvn -B -ntp package
docker compose up -d --build
curl http://127.0.0.1:18280/health
```

等 `/health` 返回 `UP` 后访问 http://127.0.0.1:18280 。首次初始化 MySQL、启动 Java 需要时间，短暂 502 请先看 `docker compose logs --tail=60 app1 app2`。两个 app 使用同一个 jar，代表同一秒杀服务的两个实例，不是两种微服务。

`mvn package` 验证编译打包；本项目的业务集成测试是后面的 `scripts/verify.py`，需要运行中的真实 MySQL/Redis，不能把 Maven 的 `No tests to run` 当作业务测试通过。

`secrets/admin_token` 是实验管理令牌，可在本机读取后填入页面，不要提交或分享。创建一个新名称的活动，选阶段并提交，再用同一阶段抢购。每次创建新活动保留旧数据，不提供全库 reset。管理接口仅用于本地实验。

启动后只有 Nginx 的 18280 端口映射到宿主机回环地址，MySQL/Redis 不开放宿主机端口。如果改端口，启动时设置 `SECKILL_PORT`，Python 脚本同时设置 `SECKILL_URL`。远程部署应通过 SSH 端口转发访问本机端口。

## 三个阶段

| 路径 | 行为 |
| --- | --- |
| `POST /api/sync/{activity}/buy` | MySQL 唯一约束、条件扣减与订单创建放在一个事务 |
| `POST /api/limited/{activity}/buy` | Redis 活动级固定窗口限流，通过后走同一 MySQL 事务 |
| `POST /api/async/{activity}/buy` | Redis Lua 预占库存并写入 Stream，消费者异步落库 |

创建活动时固定阶段，三个阶段用不同活动名称，不能对同一活动混用库存入口。每个请求头 `X-Demo-User` 表示实验用户，正式系统必须从认证身份中取得用户 ID，不能信任这个可伪造请求头。

活动规则：每人每活动最多生成一笔订单，数量固定 1，取消或过期后也不能重新参与；尚未抢到资格的用户可重试。活动截止后不接收新资格，已受理任务继续落单。付款时限从创建订单开始算。所有支付仅为本地状态模拟，不涉及真实支付平台。

异步受理返回 202 `ACCEPTED`；重试返回 202 `EXISTING` 和原 request ID。`GET /api/orders/{activity}` 查询本用户状态；`QUEUED` 表示仍未落单，`UNPAID` 表示已落单待付款；终态有 `PAID`、`CANCELLED`、`REJECTED`。`POST /api/orders/{activity}/pay` 模拟付款，`.../cancel` 取消。

## 文件从哪里看

```text
src/main/java/com/jayczee/seckill/
  Api.java          HTTP 接口、实验活动、快照、故障开关
  Orders.java       MySQL 事务：落单、支付、取消、超时
  Admission.java    Redis 入口及 Lua 调用
  Worker.java       Stream 消费、超时认领、回补 outbox
src/main/resources/
  schema.sql        库存、订单、回补任务、消费失败记录
  reserve.lua       资格检查、预占、写入队列
  ack.lua           确认消费并幂等减少积压计数
  release.lua       按订单号幂等归还 Redis 库存
scripts/
  client.py         本地实验 HTTP 客户端
  activity.py       创建活动或读取对账快照，自动读取本地管理令牌
  verify.py         正确性与故障恢复集成测试
  benchmark.py      固定到达速率的对比压测
```

## 运行验证

命令行手动操作：

```bash
python3 scripts/activity.py create first-sync --mode sync
curl -X POST http://127.0.0.1:18280/api/sync/first-sync/buy -H 'X-Demo-User: user-1'
python3 scripts/activity.py snapshot first-sync
```

```bash
python3 scripts/verify.py
python3 scripts/benchmark.py --rates 100,300,600 --seconds 5 --repeats 2
```

不要同时运行两个脚本，也不要在运行验证时手动修改活动。verify 会创建独立活动、暂停实验消费者、触发一个 Java 进程退出并等待 Compose 自动重启。它不会连接已有订单 Demo 的数据库。故障开关有 300 秒有效期，测试被中断时也可通过管理接口提前关闭。

集成测试验证：三个阶段分别 300 人抢 100 件、请求到达两个实例、同一用户重复提交、支付取消并发、自动过期、队列满拒绝、MySQL 提交后未 ACK 就退出、重试五次进入待处理清单、人工恢复、限流和活动时间窗口。全部通过才写 `target/verification.json`。

同时验证 Redis 回补后、MySQL 待办标记前退出进程，重试不会多归还库存。2026-09-15 已在 Linux x86_64 和真实两个 Java 实例上运行通过；本次 Java jar 由当前源码重新构建。结果位于 `evidence/verification-2026-09-15.json`。

benchmark 使用 96 个客户端线程、最多 128 个未完成请求，固定速率调度，客户端无法发出的请求记为 `clientDropped`，不会悄悄降低目标速率。库存充足；limited 阶段阈值默认为每个窗口 80，可通过 `--limit-rate` 调整，其余阶段入口阈值为 100000。记录状态分布、接口延迟、计划到完成的延迟、调度滞后、落单量、响应结束时积压、排空后平均落单速率。结果保存在 `target/benchmark.json`。

本次最终 18 组对照记录在 `evidence/benchmark-2026-09-15.json`。600 请求/秒、持续 5 秒时，异步受理 P95 为 6.52～19.24 ms，3000 笔订单需要 30.86～31.55 秒才全部落单并对账。限流 80 阶段落单 400 笔、明确限流 2600 次；同步阶段只有 635～643 次请求实际发出，其余因客户端 128 并发上限被丢弃。不能把异步受理速率当成数据库落单吞吐，也不能忽略客户端丢弃。

`evidence/calibration-limit-200.json` 是首轮阈值 200 的结果，未标出 limitRate 字段的这份记录使用的就是 200；`environment-2026-09-15.json` 保存环境说明。宿主机还有其他服务，5 秒突发、两次重复只作对照，不是生产容量结论。

快照：`GET /admin/activities/{activity}`，请求头 `X-Admin-Token` 使用本地令牌。消费暂停或回补未送达时 Redis 与 MySQL 可能暂时不相等；停止流量并排空后，检查订单数量与 MySQL 三段库存，并核对 Redis 可用库存。

上述 Redis 库存对账仅针对 async 活动；sync、limited 阶段不执行 Redis 预占，快照中的 Redis 初始化 available 不参与其库存账，只核对 MySQL stock 和 orders。

## 故障与恢复

`POST /admin/faults` 接收 `{"activity":"活动名称","name":"故障名称","enabled":true}`，需要管理令牌。

- `pause`：暂停两个实例的新消息处理和超时认领。
- `pause-release`：暂停 Redis 库存回补，观察 MySQL 已归还但 Redis 尚未归还。
- `fail`：指定活动的消费者模拟异常，五次失败后转人工检查，不自动放弃预占。
- `crash-after-commit`：指定活动的一个消费者在事务提交后、消息确认前退出一次。
- `crash-after-release`：指定活动的一个消费者在 Redis 回补后、MySQL 待办标记之前退出一次，验证重试不重复加库存。

移除 `fail` 后，再 `POST /admin/activities/{activity}/retry` 清零失败次数，等待 pending 任务认领。不要看到失败就直接 `INCR` 库存：数据库可能已经提交，只是确认消息时失败了。

## 范围

- Redis 是单实例，AOF `everysec` 仍可能丢失最近约一秒的写入；本实验不是零丢失、高可用方案。Redis 故障期间接口失败，不自动绕过预占直写 MySQL。
- Lua 保证脚本执行期间不被其他命令插入，不提供 SQL 式回滚。活动键结构由程序创建，禁止人工改类型；资源耗尽或进程故障仍需恢复检查。
- 所有 Redis 键共用 `{seckill}` hash tag，方便脚本键同槽；它们仍是一个热点，增加应用实例不能消除这个热点。
- 消费失败超过五次保留 pending 和库存资格，等待人工处理；不是无限自动重试。pending 空闲 3 秒可被其他实例认领，慢消费者可能导致重复处理，数据库幂等仍必需。
- 取消/超时在 MySQL 事务中写回补 outbox，独立任务幂等更新 Redis 后标记已发送。两边不能原子提交，允许暂时少售并靠重试恢复。
- 没有对历史 Stream、幂等集合、活动数据自动过期/裁剪，避免把未确认任务误删。长期运行需要按活动归档，在消费和补偿全部结束后再清理；不要把本教学默认值直接用于生产。
- 不实现登录风控、真实支付、CDN、跨机房、自动扩容、库存分桶；也不声称有限的同机压测是生产容量。

## 清理

```bash
docker compose down
```

保留具名卷与本地密码，后续可以继续查询实验结果。确认不再需要实验数据时才运行 `docker compose down -v`；不要仅删除密码后复用旧 MySQL 数据卷。

源码及公开实验记录中不含数据库密码、管理令牌或服务器地址。源码包不带 jar，需要自行构建。
