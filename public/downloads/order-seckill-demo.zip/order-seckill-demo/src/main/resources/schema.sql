CREATE TABLE IF NOT EXISTS activity (
  id VARCHAR(64) PRIMARY KEY,
  mode VARCHAR(16) NOT NULL,
  total INT NOT NULL,
  available INT NOT NULL,
  locked INT NOT NULL DEFAULT 0,
  sold INT NOT NULL DEFAULT 0,
  starts_at BIGINT NOT NULL,
  ends_at BIGINT NOT NULL,
  ttl_seconds INT NOT NULL,
  CHECK (available >= 0 AND locked >= 0 AND sold >= 0),
  CHECK (total = available + locked + sold)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS orders (
  id VARCHAR(36) PRIMARY KEY,
  activity_id VARCHAR(64) NOT NULL,
  user_id VARCHAR(64) NOT NULL,
  status VARCHAR(16) NOT NULL,
  expires_at BIGINT NOT NULL,
  UNIQUE KEY one_purchase (activity_id, user_id),
  KEY expiry (status, expires_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS release_outbox (
  order_id VARCHAR(36) PRIMARY KEY,
  activity_id VARCHAR(64) NOT NULL,
  delivered BOOLEAN NOT NULL DEFAULT FALSE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS consumer_failure (
  message_id VARCHAR(40) PRIMARY KEY,
  activity_id VARCHAR(64) NOT NULL,
  attempts INT NOT NULL,
  error_type VARCHAR(120) NOT NULL,
  needs_review BOOLEAN NOT NULL DEFAULT FALSE
) ENGINE=InnoDB;
