if redis.call('SISMEMBER', KEYS[3], ARGV[2]) == 0 then
  redis.call('HINCRBY', KEYS[2], 'backlog', -1)
  redis.call('SADD', KEYS[3], ARGV[2])
end
return redis.call('XACK', KEYS[1], ARGV[1], ARGV[2])
