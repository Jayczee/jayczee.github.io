local previous = redis.call('HGET', KEYS[2], ARGV[1])
if previous then return {'EXISTING', previous} end
if redis.call('HGET', KEYS[1], 'mode') ~= 'async' then return {'NOT_FOUND', ''} end
local now = tonumber(redis.call('TIME')[1])
if now < tonumber(redis.call('HGET', KEYS[1], 'starts')) then return {'NOT_STARTED', ''} end
if now >= tonumber(redis.call('HGET', KEYS[1], 'ends')) then return {'ENDED', ''} end
if tonumber(redis.call('HGET', KEYS[1], 'available')) <= 0 then return {'SOLD_OUT', ''} end
local count = redis.call('INCR', KEYS[4])
if count == 1 then redis.call('EXPIRE', KEYS[4], 1) end
if count > tonumber(redis.call('HGET', KEYS[1], 'rate')) then return {'LIMITED', ''} end
if tonumber(redis.call('HGET', KEYS[1], 'backlog')) >= tonumber(redis.call('HGET', KEYS[1], 'maxBacklog')) then return {'BUSY', ''} end
redis.call('XADD', KEYS[3], '*', 'activity', ARGV[3], 'user', ARGV[1], 'request', ARGV[2])
redis.call('HSET', KEYS[2], ARGV[1], ARGV[2])
redis.call('HINCRBY', KEYS[1], 'available', -1)
redis.call('HINCRBY', KEYS[1], 'backlog', 1)
return {'ACCEPTED', ARGV[2]}
