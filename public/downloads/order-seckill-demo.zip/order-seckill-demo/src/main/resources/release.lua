if redis.call('SISMEMBER', KEYS[2], ARGV[1]) == 1 then return 0 end
if redis.call('HEXISTS', KEYS[1], 'available') == 0 then return -1 end
redis.call('HINCRBY', KEYS[1], 'available', 1)
redis.call('SADD', KEYS[2], ARGV[1])
return 1
