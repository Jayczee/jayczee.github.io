package com.jayczee.seckill;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;
import java.time.Instant;
import java.util.List;
import java.util.Map;

@Service
public class Orders {
    private final JdbcTemplate db;
    private final TransactionTemplate tx;

    public Orders(JdbcTemplate db, TransactionTemplate tx) {
        this.db = db;
        this.tx = tx;
    }

    public Map<String, Object> find(String activity, String user) {
        List<Map<String, Object>> rows = db.queryForList(
                "SELECT id,status,expires_at FROM orders WHERE activity_id=? AND user_id=?", activity, user);
        return rows.isEmpty() ? Map.of("status", "NOT_FOUND") : rows.get(0);
    }

    public Map<String, Object> create(String activity, String user, String request, String mode) {
        return tx.execute(transaction -> {
            long now = Instant.now().getEpochSecond();
            List<Map<String, Object>> rows = db.queryForList("SELECT * FROM activity WHERE id=? AND mode=?", activity, mode);
            if (rows.isEmpty()) return Map.of("status", "NOT_FOUND");
            Map<String, Object> settings = rows.get(0);
            long expires = now + ((Number) settings.get("ttl_seconds")).longValue();
            int inserted = db.update("INSERT IGNORE INTO orders(id,activity_id,user_id,status,expires_at) VALUES(?,?,?,'CREATING',?)",
                    request, activity, user, expires);
            if (inserted == 0) {
                return db.queryForMap("SELECT id,status,expires_at FROM orders WHERE activity_id=? AND user_id=? FOR UPDATE", activity, user);
            }
            if (!mode.equals("async") && (now < ((Number) settings.get("starts_at")).longValue()
                    || now >= ((Number) settings.get("ends_at")).longValue())) {
                transaction.setRollbackOnly();
                return Map.of("status", "INACTIVE");
            }
            int changed = db.update("UPDATE activity SET available=available-1,locked=locked+1 WHERE id=? AND available>0", activity);
            if (changed == 0 && !mode.equals("async")) {
                transaction.setRollbackOnly();
                return Map.of("status", "SOLD_OUT");
            }
            String status = changed == 1 ? "UNPAID" : "REJECTED";
            db.update("UPDATE orders SET status=? WHERE id=?", status, request);
            if (changed == 0) db.update("INSERT INTO release_outbox(order_id,activity_id) VALUES(?,?)", request, activity);
            return Map.of("id", request, "status", status, "expires_at", expires);
        });
    }

    public Map<String, Object> finish(String activity, String user, boolean pay) {
        return tx.execute(transaction -> {
            List<Map<String, Object>> rows = db.queryForList(
                    "SELECT * FROM orders WHERE activity_id=? AND user_id=? FOR UPDATE", activity, user);
            if (rows.isEmpty()) return Map.of("status", "NOT_FOUND");
            Map<String, Object> order = rows.get(0);
            if (!order.get("status").equals("UNPAID")) return Map.of("status", order.get("status"));
            long now = Instant.now().getEpochSecond();
            boolean paid = pay && now < ((Number) order.get("expires_at")).longValue();
            String status = paid ? "PAID" : "CANCELLED";
            db.update("UPDATE orders SET status=? WHERE id=? AND status='UNPAID'", status, order.get("id"));
            db.update(paid ? "UPDATE activity SET locked=locked-1,sold=sold+1 WHERE id=?"
                    : "UPDATE activity SET locked=locked-1,available=available+1 WHERE id=?", activity);
            if (!paid && "async".equals(db.queryForObject("SELECT mode FROM activity WHERE id=?", String.class, activity))) {
                db.update("INSERT INTO release_outbox(order_id,activity_id) VALUES(?,?)", order.get("id"), activity);
            }
            return Map.of("status", status);
        });
    }

    public void expire() {
        for (Map<String, Object> order : db.queryForList(
                "SELECT activity_id,user_id FROM orders WHERE status='UNPAID' AND expires_at<=? LIMIT 100", Instant.now().getEpochSecond())) {
            finish(order.get("activity_id").toString(), order.get("user_id").toString(), false);
        }
    }
}
