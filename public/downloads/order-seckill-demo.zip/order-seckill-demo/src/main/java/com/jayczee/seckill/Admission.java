package com.jayczee.seckill;

import io.lettuce.core.ScriptOutputType;
import io.lettuce.core.api.sync.RedisCommands;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class Admission {
    public static final String STREAM = "{seckill}:tasks";
    public static final String GROUP = "orders";
    private final RedisCommands<String, String> redis;
    private final String reserve;

    public Admission(RedisCommands<String, String> redis) throws IOException {
        this.redis = redis;
        reserve = new ClassPathResource("reserve.lua").getContentAsString(StandardCharsets.UTF_8);
    }

    public static String key(String activity) { return "{seckill}:activity:" + activity; }

    public Map<String, Object> reserve(String activity, String user) {
        String base = key(activity);
        List<String> result = redis.eval(reserve, ScriptOutputType.MULTI,
                new String[]{base, base + ":users", STREAM, base + ":rate"}, user, UUID.randomUUID().toString(), activity);
        return Map.of("status", result.get(0), "id", result.get(1));
    }

    public boolean limited(String activity) {
        String base = key(activity);
        Long result = redis.eval("local count=redis.call('INCR',KEYS[1]); if count==1 then redis.call('EXPIRE',KEYS[1],1) end; return count",
                ScriptOutputType.INTEGER, new String[]{base + ":rate"});
        String rate = redis.hget(base, "rate");
        return rate == null || result > Long.parseLong(rate);
    }

    public Map<String, Object> queued(String activity, String user) {
        String request = redis.hget(key(activity) + ":users", user);
        return request == null ? Map.of("status", "NOT_FOUND") : Map.of("status", "QUEUED", "id", request);
    }
}
