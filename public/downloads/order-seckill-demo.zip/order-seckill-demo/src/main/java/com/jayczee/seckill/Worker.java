package com.jayczee.seckill;

import io.lettuce.core.Consumer;
import io.lettuce.core.Limit;
import io.lettuce.core.Range;
import io.lettuce.core.RedisCommandExecutionException;
import io.lettuce.core.ScriptOutputType;
import io.lettuce.core.StreamMessage;
import io.lettuce.core.XGroupCreateArgs;
import io.lettuce.core.XReadArgs;
import io.lettuce.core.api.sync.RedisCommands;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.UUID;

@Component
public class Worker {
    private static final Logger LOG = LoggerFactory.getLogger(Worker.class);
    private final RedisCommands<String, String> redis;
    private final Orders orders;
    private final JdbcTemplate db;
    private final String consumer = UUID.randomUUID().toString();
    private final String ackScript;
    private final String releaseScript;
    private String pendingCursor;

    public Worker(RedisCommands<String, String> redis, Orders orders, JdbcTemplate db) throws IOException {
        this.redis = redis;
        this.orders = orders;
        this.db = db;
        ackScript = new ClassPathResource("ack.lua").getContentAsString(StandardCharsets.UTF_8);
        releaseScript = new ClassPathResource("release.lua").getContentAsString(StandardCharsets.UTF_8);
        try {
            redis.xgroupCreate(XReadArgs.StreamOffset.from(Admission.STREAM, "0"), Admission.GROUP,
                    XGroupCreateArgs.Builder.mkstream());
        } catch (RedisCommandExecutionException exception) {
            if (!exception.getMessage().contains("BUSYGROUP")) throw exception;
        }
    }

    @Scheduled(fixedDelay = 50)
    public void consume() {
        try {
            if (redis.exists("{seckill}:pause") > 0) return;
            for (StreamMessage<String, String> message : redis.xreadgroup(
                    Consumer.from(Admission.GROUP, consumer), XReadArgs.Builder.count(20),
                    XReadArgs.StreamOffset.lastConsumed(Admission.STREAM))) process(message);
        } catch (Exception exception) {
            LOG.warn("Consumer deferred: {}", exception.getClass().getSimpleName());
        }
    }

    @Scheduled(fixedDelay = 1000)
    public void recover() {
        try {
            if (redis.exists("{seckill}:pause") > 0) return;
            Range<String> range = pendingCursor == null ? Range.unbounded()
                    : Range.from(Range.Boundary.excluding(pendingCursor), Range.Boundary.unbounded());
            var pending = redis.xpending(Admission.STREAM, Admission.GROUP, range, Limit.from(100));
            if (pending.isEmpty()) pendingCursor = null;
            for (var message : pending) {
                pendingCursor = message.getId();
                if (message.getMsSinceLastDelivery() < 3000) continue;
                for (var claimed : redis.xclaim(Admission.STREAM, Consumer.from(Admission.GROUP, consumer), 3000, message.getId())) process(claimed);
            }
        } catch (Exception exception) {
            LOG.warn("Recovery deferred: {}", exception.getClass().getSimpleName());
        }
    }

    private void process(StreamMessage<String, String> message) {
        Map<String, String> body = message.getBody();
        String activity = body.get("activity");
        try {
            Integer blocked = db.queryForObject("SELECT COUNT(*) FROM consumer_failure WHERE message_id=? AND needs_review=TRUE", Integer.class, message.getId());
            if (blocked != null && blocked > 0) return;
            if (redis.exists(Admission.key(activity) + ":fail") > 0) throw new IllegalStateException("Injected failure");
            Map<String, Object> order = orders.create(activity, body.get("user"), body.get("request"), "async");
            if ("NOT_FOUND".equals(order.get("status"))) throw new IllegalStateException("Missing activity");
            if (redis.getdel(Admission.key(activity) + ":crash-after-commit") != null) Runtime.getRuntime().halt(23);
            db.update("DELETE FROM consumer_failure WHERE message_id=?", message.getId());
        } catch (Exception exception) {
            db.update("INSERT INTO consumer_failure(message_id,activity_id,attempts,error_type) VALUES(?,?,1,?) "
                            + "ON DUPLICATE KEY UPDATE attempts=attempts+1,error_type=VALUES(error_type),needs_review=(attempts>=5)",
                    message.getId(), activity, exception.getClass().getSimpleName());
            LOG.warn("Task {} deferred: {}", message.getId(), exception.getClass().getSimpleName());
            return;
        }
        try {
            redis.eval(ackScript, ScriptOutputType.INTEGER,
                    new String[]{Admission.STREAM, Admission.key(activity), "{seckill}:acked"}, Admission.GROUP, message.getId());
        } catch (Exception exception) {
            LOG.warn("Task {} acknowledgement uncertain: {}", message.getId(), exception.getClass().getSimpleName());
        }
    }

    @Scheduled(fixedDelay = 500)
    public void release() {
        try {
            if (redis.exists("{seckill}:pause-release") > 0) return;
            for (Map<String, Object> row : db.queryForList("SELECT * FROM release_outbox WHERE delivered=FALSE LIMIT 100")) {
                String activity = row.get("activity_id").toString();
                Long released = redis.eval(releaseScript, ScriptOutputType.INTEGER,
                        new String[]{Admission.key(activity), Admission.key(activity) + ":released"}, row.get("order_id").toString());
                if (released < 0) throw new IllegalStateException("Missing Redis stock; reconcile before retry");
                if (redis.getdel(Admission.key(activity) + ":crash-after-release") != null) Runtime.getRuntime().halt(24);
                db.update("UPDATE release_outbox SET delivered=TRUE WHERE order_id=?", row.get("order_id"));
            }
        } catch (Exception exception) {
            LOG.warn("Release deferred: {}", exception.getClass().getSimpleName());
        }
    }

    @Scheduled(fixedDelay = 1000)
    public void expire() { orders.expire(); }
}
