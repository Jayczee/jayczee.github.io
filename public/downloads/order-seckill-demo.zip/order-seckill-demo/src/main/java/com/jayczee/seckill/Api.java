package com.jayczee.seckill;

import io.lettuce.core.api.sync.RedisCommands;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

@RestController
public class Api {
    private final Orders orders;
    private final Admission admission;
    private final RedisCommands<String, String> redis;
    private final JdbcTemplate db;
    private final String adminToken;

    public Api(Orders orders, Admission admission, RedisCommands<String, String> redis,
               JdbcTemplate db, @Value("${admin_token}") String adminToken) {
        this.orders = orders;
        this.admission = admission;
        this.redis = redis;
        this.db = db;
        this.adminToken = adminToken;
    }

    @GetMapping("/health")
    public Map<String, Object> health() {
        db.queryForObject("SELECT 1", Integer.class);
        redis.ping();
        return Map.of("status", "UP", "instance", System.getenv().getOrDefault("HOSTNAME", "local"));
    }

    @PostMapping("/api/{mode}/{activity}/buy")
    public ResponseEntity<Map<String, Object>> buy(@PathVariable String mode, @PathVariable String activity,
                                                  @RequestHeader("X-Demo-User") String user) {
        valid(activity); valid(user);
        if (!Set.of("sync", "limited", "async").contains(mode)) throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        Map<String, Object> result;
        if (mode.equals("async")) result = admission.reserve(activity, user);
        else if (mode.equals("limited") && admission.limited(activity)) result = Map.of("status", "LIMITED");
        else result = orders.create(activity, user, UUID.randomUUID().toString(), mode);
        String status = result.get("status").toString();
        int code = switch (status) {
            case "ACCEPTED", "EXISTING" -> 202;
            case "LIMITED", "BUSY" -> 429;
            case "SOLD_OUT", "INACTIVE", "NOT_STARTED", "ENDED" -> 409;
            case "NOT_FOUND" -> 404;
            default -> 200;
        };
        return ResponseEntity.status(code).header("X-Instance", System.getenv().getOrDefault("HOSTNAME", "local")).body(result);
    }

    @GetMapping("/api/orders/{activity}")
    public Map<String, Object> result(@PathVariable String activity, @RequestHeader("X-Demo-User") String user) {
        valid(activity); valid(user);
        Map<String, Object> order = orders.find(activity, user);
        return "NOT_FOUND".equals(order.get("status")) ? admission.queued(activity, user) : order;
    }

    @PostMapping("/api/orders/{activity}/{action}")
    public Map<String, Object> finish(@PathVariable String activity, @PathVariable String action,
                                      @RequestHeader("X-Demo-User") String user) {
        valid(activity); valid(user);
        if (!Set.of("pay", "cancel").contains(action)) throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        return orders.finish(activity, user, action.equals("pay"));
    }

    public record Activity(String id, String mode, int stock, int rate, int maxBacklog,
                           int ttlSeconds, int startDelaySeconds, int durationSeconds) {}

    @PostMapping("/admin/activities")
    public Map<String, Object> create(@RequestHeader("X-Admin-Token") String token, @RequestBody Activity activity) {
        admin(token); valid(activity.id());
        if (!Set.of("sync", "limited", "async").contains(activity.mode()) || activity.stock() < 1
                || activity.stock() > 1_000_000 || activity.rate() < 1 || activity.maxBacklog() < 1
                || activity.ttlSeconds() < 2 || activity.startDelaySeconds() < 0 || activity.durationSeconds() < 1) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
        }
        long starts = Instant.now().getEpochSecond() + activity.startDelaySeconds();
        long ends = starts + activity.durationSeconds();
        db.update("INSERT INTO activity(id,mode,total,available,starts_at,ends_at,ttl_seconds) VALUES(?,?,?,?,?,?,?)",
                activity.id(), activity.mode(), activity.stock(), activity.stock(), starts, ends, activity.ttlSeconds());
        redis.hset(Admission.key(activity.id()), Map.of("mode", activity.mode(), "available", "" + activity.stock(),
                "starts", "" + starts, "ends", "" + ends, "rate", "" + activity.rate(),
                "backlog", "0", "maxBacklog", "" + activity.maxBacklog()));
        return Map.of("id", activity.id(), "status", "READY");
    }

    @GetMapping("/admin/activities/{activity}")
    public Map<String, Object> snapshot(@RequestHeader("X-Admin-Token") String token, @PathVariable String activity) {
        admin(token); valid(activity);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("stock", db.queryForMap("SELECT * FROM activity WHERE id=?", activity));
        result.put("orders", db.queryForList("SELECT status,COUNT(*) AS count FROM orders WHERE activity_id=? GROUP BY status", activity));
        result.put("redis", redis.hgetall(Admission.key(activity)));
        result.put("users", redis.hlen(Admission.key(activity) + ":users"));
        result.put("undeliveredReleases", db.queryForObject("SELECT COUNT(*) FROM release_outbox WHERE activity_id=? AND delivered=FALSE", Integer.class, activity));
        result.put("failures", db.queryForList("SELECT * FROM consumer_failure WHERE activity_id=?", activity));
        return result;
    }

    public record Fault(String activity, String name, boolean enabled) {}

    @PostMapping("/admin/faults")
    public Map<String, Object> fault(@RequestHeader("X-Admin-Token") String token, @RequestBody Fault fault) {
        admin(token); valid(fault.activity());
        if (!Set.of("pause", "pause-release", "fail", "crash-after-commit", "crash-after-release").contains(fault.name())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
        String key = fault.name().startsWith("pause") ? "{seckill}:" + fault.name() : Admission.key(fault.activity()) + ":" + fault.name();
        if (fault.enabled()) redis.setex(key, 300, "1"); else redis.del(key);
        return Map.of("status", "OK");
    }

    @PostMapping("/admin/activities/{activity}/retry")
    public Map<String, Object> retry(@RequestHeader("X-Admin-Token") String token, @PathVariable String activity) {
        admin(token); valid(activity);
        db.update("UPDATE consumer_failure SET attempts=0,needs_review=FALSE WHERE activity_id=?", activity);
        return Map.of("status", "OK");
    }

    private void admin(String token) {
        if (!MessageDigest.isEqual(adminToken.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8))) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
    }

    private void valid(String value) {
        if (value == null || !value.matches("[a-zA-Z0-9_-]{1,64}")) throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
    }
}
