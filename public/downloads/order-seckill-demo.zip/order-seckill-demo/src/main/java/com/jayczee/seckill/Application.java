package com.jayczee.seckill;

import io.lettuce.core.RedisClient;
import io.lettuce.core.RedisURI;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.api.sync.RedisCommands;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import java.time.Duration;

@SpringBootApplication
@EnableScheduling
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean(destroyMethod = "shutdown")
    RedisClient redisClient(@Value("${REDIS_HOST:localhost}") String host,
                            @Value("${redis_password}") String password) {
        return RedisClient.create(RedisURI.Builder.redis(host).withPassword(password.toCharArray())
                .withTimeout(Duration.ofSeconds(2)).build());
    }

    @Bean(destroyMethod = "close")
    StatefulRedisConnection<String, String> redisConnection(RedisClient client) {
        return client.connect();
    }

    @Bean
    RedisCommands<String, String> redis(StatefulRedisConnection<String, String> connection) {
        return connection.sync();
    }
}
