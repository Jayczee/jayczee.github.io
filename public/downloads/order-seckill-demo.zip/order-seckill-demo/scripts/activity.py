import argparse
import json
from client import create, snapshot

parser = argparse.ArgumentParser()
parser.add_argument('action', choices=['create', 'snapshot'])
parser.add_argument('name')
parser.add_argument('--mode', choices=['sync', 'limited', 'async'], default='async')
parser.add_argument('--stock', type=int, default=100)
parser.add_argument('--rate', type=int, default=80)
parser.add_argument('--backlog', type=int, default=1000)
parser.add_argument('--ttl', type=int, default=300)
args = parser.parse_args()
if args.action == 'create':
    create(args.name, mode=args.mode, stock=args.stock, rate=args.rate, backlog=args.backlog, ttl=args.ttl)
print(json.dumps(snapshot(args.name), ensure_ascii=False, indent=2))
