from concurrent.futures import ThreadPoolExecutor
import json
import time
from client import ROOT, request, create, snapshot, fault, until, settled

prefix = 'verify-' + str(time.time_ns())
results = {}


def buy(activity, user, mode='async'):
    return request(f'/api/{mode}/{activity}/buy', 'POST', user=user)


def status(activity, user):
    return request('/api/orders/' + activity, user=user)[1]['status']


def burst(activity, users, mode='async'):
    with ThreadPoolExecutor(max_workers=40) as pool:
        return list(pool.map(lambda user: buy(activity, user, mode), users))


until(lambda: request('/health')[0] == 200)
for mode in ('sync', 'limited', 'async'):
    activity = prefix + '-' + mode
    create(activity, mode)
    answers = burst(activity, range(300), mode)
    assert all(code < 500 for code, _, _ in answers)
    state = until(lambda: settled(activity))
    assert state['stock']['locked'] == 100, state
    assert len({instance for _, _, instance in answers if instance}) == 2
    results[mode + '-300-for-100'] = state
    if mode == 'async':
        winners = [str(user) for user, (_, body, _) in enumerate(answers) if body['status'] == 'ACCEPTED']
        assert len(winners) == 100
        fault(activity, 'pause-release', True)
        with ThreadPoolExecutor(max_workers=40) as pool:
            list(pool.map(lambda pair: request(f'/api/orders/{activity}/' + ('pay' if pair[0] < 50 else 'cancel'), 'POST', user=pair[1]), enumerate(winners)))
        before = snapshot(activity)
        assert before['stock']['sold'] == 50 and before['stock']['available'] == 50
        assert int(before['redis']['available']) == 0 and before['undeliveredReleases'] == 50
        fault(activity, 'pause-release', False)
        results['pay-cancel-outbox'] = until(lambda: settled(activity))
        assert status(activity, winners[0]) == 'PAID'
        for user in winners[50:]:
            request(f'/api/orders/{activity}/cancel', 'POST', user=user)
        assert until(lambda: settled(activity))['stock']['available'] == 50

activity = prefix + '-dedup'
create(activity, stock=10)
answers = burst(activity, ['same-user'] * 100)
assert len({body['id'] for _, body, _ in answers}) == 1
assert until(lambda: settled(activity))['stock']['locked'] == 1
with ThreadPoolExecutor(max_workers=20) as pool:
    list(pool.map(lambda count: request(f'/api/orders/{activity}/' + ('pay' if count % 2 else 'cancel'), 'POST', user='same-user'), range(40)))
results['dedup-and-pay-cancel-race'] = until(lambda: settled(activity))
assert results['dedup-and-pay-cancel-race']['stock']['locked'] == 0

activity = prefix + '-ttl'
create(activity, stock=1, ttl=2)
assert buy(activity, 'expire')[0] == 202
until(lambda: status(activity, 'expire') == 'CANCELLED')
results['expiry'] = until(lambda: settled(activity))
assert results['expiry']['stock']['available'] == 1

activity = prefix + '-release-crash'
create(activity, stock=1)
assert buy(activity, 'release')[0] == 202
until(lambda: status(activity, 'release') == 'UNPAID')
fault(activity, 'crash-after-release', True)
assert request(f'/api/orders/{activity}/cancel', 'POST', user='release')[0] == 200
results['release-before-outbox-mark-process-crash'] = until(lambda: settled(activity))
assert results['release-before-outbox-mark-process-crash']['stock']['available'] == 1
until(lambda: all(buy(activity, 'release')[0] == 202 for _ in range(4)), timeout=30)

activity = prefix + '-backlog'
create(activity, stock=20, backlog=5)
fault(activity, 'pause', True)
try:
    answers = burst(activity, range(20))
    assert sum(body['status'] == 'ACCEPTED' for _, body, _ in answers) == 5
    assert sum(body['status'] == 'BUSY' for _, body, _ in answers) == 15
    results['bounded-backlog'] = snapshot(activity)
finally:
    fault(activity, 'pause', False)
until(lambda: settled(activity))

activity = prefix + '-crash'
create(activity, stock=1)
fault(activity, 'crash-after-commit', True)
assert buy(activity, 'crash')[0] == 202
results['commit-before-ack-process-crash'] = until(lambda: settled(activity))
assert results['commit-before-ack-process-crash']['stock']['locked'] == 1

activity = prefix + '-poison'
create(activity, stock=1)
fault(activity, 'fail', True)
assert buy(activity, 'poison')[0] == 202
until(lambda: any(row['needs_review'] for row in snapshot(activity)['failures']), timeout=60)
results['quarantine'] = snapshot(activity)
assert results['quarantine']['stock']['locked'] == 0
fault(activity, 'fail', False)
assert request('/admin/activities/' + activity + '/retry', 'POST', admin=True)[0] == 200
results['manual-recovery'] = until(lambda: settled(activity))
assert results['manual-recovery']['stock']['locked'] == 1

activity = prefix + '-rate'
create(activity, stock=300, rate=1)
answers = burst(activity, range(30))
assert any(body['status'] == 'LIMITED' for _, body, _ in answers)
until(lambda: settled(activity))
results['rate-limit'] = {'limited': sum(body['status'] == 'LIMITED' for _, body, _ in answers)}

activity = prefix + '-window'
create(activity, stock=1, delay=2, duration=2)
assert buy(activity, 'window')[1]['status'] == 'NOT_STARTED'
time.sleep(4.1)
assert buy(activity, 'window')[1]['status'] == 'ENDED'
results['activity-window'] = 'passed'

(ROOT / 'target').mkdir(exist_ok=True)
(ROOT / 'target/verification.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
print('PASS:', ', '.join(results))
