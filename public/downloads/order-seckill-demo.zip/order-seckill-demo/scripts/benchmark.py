import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, wait
import json
import math
import platform
import threading
import time
from client import ROOT, request, create, snapshot, settled, until

parser = argparse.ArgumentParser()
parser.add_argument('--rates', default='100,300,600')
parser.add_argument('--seconds', type=int, default=5)
parser.add_argument('--repeats', type=int, default=2)
parser.add_argument('--limit-rate', type=int, default=80)
args = parser.parse_args()
assert 1 <= args.seconds <= 30 and 1 <= args.repeats <= 5
rates = [int(value) for value in args.rates.split(',')]
assert all(1 <= rate <= 1000 for rate in rates)
prefix = 'bench-' + str(time.time_ns())
report = {'platform': platform.platform(), 'seconds': args.seconds, 'repeats': args.repeats, 'limitRate': args.limit_rate,
          'workers': 96, 'clientOutstandingLimit': 128, 'runs': []}


def percentile(values, fraction):
    values = sorted(values)
    return round(values[max(0, math.ceil(len(values) * fraction) - 1)] * 1000, 2) if values else None


for repeat in range(args.repeats):
    for rate in rates:
        for mode in ('sync', 'limited', 'async'):
            activity = f'{prefix}-{repeat}-{rate}-{mode}'
            total = rate * args.seconds
            create(activity, mode, stock=total + 100, rate=args.limit_rate if mode == 'limited' else 100000, backlog=5000)
            samples = []
            dropped = 0
            slots = threading.BoundedSemaphore(128)

            def send(index, scheduled):
                began = time.monotonic()
                try:
                    code, body, _ = request(f'/api/{mode}/{activity}/buy', 'POST', user=f'user-{index}')
                    status = body.get('status', 'UNKNOWN')
                except (OSError, ValueError):
                    code, status = 0, 'CLIENT_ERROR'
                finally:
                    ended = time.monotonic()
                    slots.release()
                return {'http': code, 'status': status, 'latency': ended - began, 'scheduledLatency': ended - scheduled, 'sendLag': began - scheduled}

            with ThreadPoolExecutor(max_workers=96) as pool:
                start = time.monotonic()
                futures = []
                for index in range(total):
                    scheduled = start + index / rate
                    remaining = scheduled - time.monotonic()
                    if remaining > 0:
                        time.sleep(remaining)
                    if slots.acquire(blocking=False):
                        futures.append(pool.submit(send, index, scheduled))
                    else:
                        dropped += 1
                wait(futures)
                response_end = time.monotonic()
                samples = [future.result() for future in futures]
            at_response_end = snapshot(activity)
            final = until(lambda: settled(activity), timeout=120)
            completed_at = time.monotonic()
            count = sum(row['count'] for row in final['orders'] if row['status'] in ('UNPAID', 'PAID'))
            statuses = Counter(sample['status'] for sample in samples)
            accepted = [sample['latency'] for sample in samples if sample['status'] in ('UNPAID', 'ACCEPTED')]
            run = dict(mode=mode, repeat=repeat, offeredRate=rate, offered=total, sent=len(samples),
                       clientDropped=dropped, responses=dict(statuses), successfulOrders=count,
                       responseSeconds=round(response_end-start, 3),
                       responseQps=round(len(samples)/(response_end-start), 2),
                       settledSeconds=round(completed_at-start, 3),
                       orderQpsUntilSettled=round(count/(completed_at-start), 2),
                       latencyP95Ms=percentile([sample['latency'] for sample in samples], .95),
                       latencyP99Ms=percentile([sample['latency'] for sample in samples], .99),
                       admittedP95Ms=percentile(accepted, .95),
                       scheduledP99Ms=percentile([sample['scheduledLatency'] for sample in samples], .99),
                       sendLagP99Ms=percentile([sample['sendLag'] for sample in samples], .99),
                       backlogAtResponseEnd=int(at_response_end['redis']['backlog']),
                       stock=final['stock'])
            report['runs'].append(run)
            print(json.dumps(run), flush=True)
            time.sleep(1)

(ROOT / 'target').mkdir(exist_ok=True)
(ROOT / 'target/benchmark.json').write_text(json.dumps(report, indent=2))
