import json
import os
from pathlib import Path
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
BASE = os.environ.get('SECKILL_URL', 'http://127.0.0.1:18280')
TOKEN = (ROOT / 'secrets/admin_token').read_text().strip()


def request(path, method='GET', data=None, user='test', admin=False):
    headers = {'Content-Type': 'application/json', 'X-Demo-User': str(user)}
    if admin:
        headers['X-Admin-Token'] = TOKEN
    call = urllib.request.Request(BASE + path, data=json.dumps(data).encode() if data is not None else (b'' if method == 'POST' else None), headers=headers, method=method)
    try:
        with urllib.request.urlopen(call, timeout=12) as response:
            return response.status, json.load(response), response.headers.get('X-Instance')
    except urllib.error.HTTPError as error:
        try:
            body = json.load(error)
        except (ValueError, UnicodeDecodeError):
            body = {'status': 'HTTP_ERROR'}
        return error.code, body, None


def create(activity, mode='async', stock=100, rate=100000, backlog=5000, ttl=3600, delay=0, duration=3600):
    code, body, _ = request('/admin/activities', 'POST', dict(id=activity, mode=mode, stock=stock, rate=rate, maxBacklog=backlog, ttlSeconds=ttl, startDelaySeconds=delay, durationSeconds=duration), admin=True)
    assert code == 200, (code, body)


def snapshot(activity):
    code, body, _ = request('/admin/activities/' + activity, admin=True)
    assert code == 200, (code, body)
    return body


def fault(activity, name, enabled):
    assert request('/admin/faults', 'POST', dict(activity=activity, name=name, enabled=enabled), admin=True)[0] == 200


def until(check, timeout=90):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            result = check()
            if result:
                return result
        except (OSError, ValueError, AssertionError):
            pass
        time.sleep(.2)
    raise AssertionError('Timed out waiting for expected state')


def settled(activity):
    state = snapshot(activity)
    if int(state['redis']['backlog']) != 0 or state['undeliveredReleases'] != 0:
        return False
    stock = state['stock']
    counts = {row['status']: row['count'] for row in state['orders']}
    assert stock['total'] == stock['available'] + stock['locked'] + stock['sold']
    assert min(stock['available'], stock['locked'], stock['sold']) >= 0
    assert stock['locked'] == counts.get('UNPAID', 0)
    assert stock['sold'] == counts.get('PAID', 0)
    if stock['mode'] == 'async':
        assert stock['available'] == int(state['redis']['available'])
    assert not state['failures']
    return state
