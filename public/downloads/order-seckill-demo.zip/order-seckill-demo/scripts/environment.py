import json
import platform
import subprocess


def run(arguments):
    return subprocess.check_output(arguments, text=True).strip()


report = {
    'system': platform.system(),
    'architecture': platform.machine(),
    'compose': run(['docker', 'compose', 'version', '--short']),
    'java': run(['docker', 'compose', 'exec', '-T', 'app1', 'java', '--version']),
    'mysql': run(['docker', 'compose', 'exec', '-T', 'mysql', 'mysql', '--version']),
    'redis': run(['docker', 'compose', 'exec', '-T', 'redis', 'redis-server', '--version']),
    'limits': {'appInstances': 2, 'appCpuEach': 1, 'appMemoryMiBEach': 448,
               'mysqlCpu': 1, 'mysqlMemoryMiB': 640, 'redisCpu': 1, 'redisMemoryMiB': 256,
               'hikariConnectionsEach': 8, 'httpThreadsEach': 64},
    'placement': 'Load generator, Nginx, both applications, MySQL and Redis share one host with other workloads.',
}
print(json.dumps(report, indent=2))
