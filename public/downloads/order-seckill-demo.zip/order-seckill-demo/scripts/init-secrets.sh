#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p secrets
chmod 700 secrets
for name in mysql_password redis_password admin_token; do
  if [ ! -f "secrets/$name" ]; then
    openssl rand -hex 32 > "secrets/$name"
  fi
  chmod 644 "secrets/$name"
done
echo 'Local secrets are ready. Keep this directory out of Git and download archives.'
