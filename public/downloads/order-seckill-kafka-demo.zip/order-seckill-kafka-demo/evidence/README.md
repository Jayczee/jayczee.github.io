# 2026-09-16 实验记录

当前源码在本地 Maven 编译，jar 传到 NAS 后构建镜像，在独立 Compose 项目执行。没有复用旧项目的 jar，没有使用 Redis、Redis Stream 或 ZooKeeper。

- verification-2026-09-16.json：13 组结果记录，覆盖 300 抢 100、重复申请、支付取消、积压上限、两个确认边界的进程退出、DLT 重放、超时和 Kafka 停机后补发。
- queue-lab-2026-09-16.json：暂停消费后 60 条消息的 lag 为 22/19/19，恢复后均为 0，生成 60 笔订单。
- environment-2026-09-16.json：客户端、broker、MySQL 版本和容器资源限制。

record 中的 container ID 与 Docker 网络地址只用于确认两个消费实例。consumer-id 的随机后缀、topic offset、活动 ID 每次运行都会改变，不应写死作为测试期望。

本实验是单 NAS、单 broker、单副本。实际退出 Java 进程、停止再启动 Kafka，数据卷始终保留；没有执行主机断电、磁盘损坏、网络分区或多 broker 故障转移测试。不据此宣称高可用或零丢失。

积压实验采用人为暂停消费者的方法，用来展示受理、发送、消费三个状态的区别，不是高 QPS 压测。每次运行创建新活动，不清空旧实验表。
