CREATE TABLE IF NOT EXISTS activity (
  id VARCHAR(64) PRIMARY KEY,
  total INT NOT NULL,
  available INT NOT NULL,
  locked INT NOT NULL DEFAULT 0,
  sold INT NOT NULL DEFAULT 0,
  ttl_seconds INT NOT NULL,
  max_pending INT NOT NULL,
  starts_at BIGINT NOT NULL,
  ends_at BIGINT NOT NULL,
  CHECK (available >= 0 AND locked >= 0 AND sold >= 0),
  CHECK (available + locked + sold = total)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS requests (
  id VARCHAR(36) PRIMARY KEY,
  activity_id VARCHAR(64) NOT NULL,
  user_id VARCHAR(64) NOT NULL,
  status VARCHAR(24) NOT NULL,
  expires_at BIGINT,
  created_at BIGINT NOT NULL,
  UNIQUE KEY one_purchase (activity_id,user_id),
  KEY pending (activity_id,status)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS orders (
  request_id VARCHAR(36) PRIMARY KEY,
  activity_id VARCHAR(64) NOT NULL,
  user_id VARCHAR(64) NOT NULL,
  consumer_id VARCHAR(80) NOT NULL,
  partition_id INT NOT NULL,
  message_offset BIGINT NOT NULL,
  UNIQUE KEY one_order (activity_id,user_id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS outbox (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  request_id VARCHAR(36) NOT NULL,
  delivered BOOLEAN NOT NULL DEFAULT FALSE,
  attempts INT NOT NULL DEFAULT 0,
  next_attempt BIGINT NOT NULL DEFAULT 0,
  lease_until BIGINT NOT NULL DEFAULT 0,
  lease_owner VARCHAR(36),
  error_type VARCHAR(120),
  KEY pending (delivered,next_attempt,lease_until)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS failed_message (
  message_id VARCHAR(120) PRIMARY KEY,
  request_id VARCHAR(36),
  payload TEXT NOT NULL,
  resolved BOOLEAN NOT NULL DEFAULT FALSE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS fault (
  name VARCHAR(120) PRIMARY KEY,
  expires_at BIGINT NOT NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS delivery_attempt (
  request_id VARCHAR(36) PRIMARY KEY,
  attempts INT NOT NULL
) ENGINE=InnoDB;
