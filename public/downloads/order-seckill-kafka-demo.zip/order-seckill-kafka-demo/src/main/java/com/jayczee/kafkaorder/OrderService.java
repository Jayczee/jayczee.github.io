package com.jayczee.kafkaorder;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class OrderService {
    private final JdbcTemplate db;
    private final TransactionTemplate tx;
    public OrderService(JdbcTemplate db, TransactionTemplate tx) { this.db = db; this.tx = tx; }

    public Map<String, Object> accept(String activity, String user) {
        return tx.execute(transaction -> {
            List<Map<String, Object>> activities = db.queryForList("SELECT * FROM activity WHERE id=? FOR UPDATE", activity);
            if (activities.isEmpty()) return Map.of("status", "NOT_FOUND");
            List<Map<String, Object>> prior = db.queryForList("SELECT * FROM requests WHERE activity_id=? AND user_id=? FOR UPDATE", activity, user);
            if (!prior.isEmpty()) return prior.get(0);
            Map<String, Object> settings = activities.get(0);
            long now = Instant.now().getEpochSecond();
            if (now < number(settings, "starts_at") || now >= number(settings, "ends_at")) return Map.of("status", "INACTIVE");
            if (number(settings, "available") == 0) return Map.of("status", "SOLD_OUT");
            int pending = db.queryForList("SELECT id FROM requests WHERE activity_id=? AND status IN ('QUEUED','MANUAL_REVIEW') FOR UPDATE", activity).size();
            if (pending >= number(settings, "max_pending")) return Map.of("status", "BUSY");
            String request = UUID.randomUUID().toString();
            int changed = db.update("UPDATE activity SET available=available-1,locked=locked+1 WHERE id=? AND available>0", activity);
            if (changed != 1) throw new IllegalStateException("Stock changed unexpectedly");
            db.update("INSERT INTO requests(id,activity_id,user_id,status,created_at) VALUES(?,?,?,'QUEUED',?)", request, activity, user, now);
            db.update("INSERT INTO outbox(request_id) VALUES(?)", request);
            return Map.of("id", request, "status", "QUEUED");
        });
    }

    public void materialize(OrderEvent event, String consumer, int partition, long offset) {
        tx.executeWithoutResult(transaction -> {
            List<Map<String, Object>> rows = db.queryForList("SELECT * FROM requests WHERE id=? FOR UPDATE", event.requestId());
            if (rows.isEmpty()) throw new IllegalArgumentException("Unknown request");
            Map<String, Object> request = rows.get(0);
            if (event.version() != 1 || !request.get("activity_id").equals(event.activityId()) || !request.get("user_id").equals(event.userId())) {
                throw new IllegalArgumentException("Event does not match accepted request");
            }
            String status = request.get("status").toString();
            if (!status.equals("QUEUED")) return;
            int ttl = db.queryForObject("SELECT ttl_seconds FROM activity WHERE id=?", Integer.class, event.activityId());
            db.update("INSERT INTO orders(request_id,activity_id,user_id,consumer_id,partition_id,message_offset) VALUES(?,?,?,?,?,?)",
                    event.requestId(), event.activityId(), event.userId(), consumer, partition, offset);
            db.update("UPDATE requests SET status='UNPAID',expires_at=? WHERE id=?", Instant.now().getEpochSecond() + ttl, event.requestId());
        });
    }

    public Map<String, Object> finish(String activity, String user, boolean pay) {
        return tx.execute(transaction -> {
            db.queryForList("SELECT id FROM activity WHERE id=? FOR UPDATE", activity);
            List<Map<String, Object>> rows = db.queryForList("SELECT * FROM requests WHERE activity_id=? AND user_id=? FOR UPDATE", activity, user);
            if (rows.isEmpty()) return Map.of("status", "NOT_FOUND");
            Map<String, Object> request = rows.get(0);
            if (!request.get("status").equals("UNPAID")) return Map.of("status", request.get("status"));
            boolean paid = pay && Instant.now().getEpochSecond() < number(request, "expires_at");
            String status = paid ? "PAID" : "CANCELLED";
            db.update("UPDATE requests SET status=? WHERE id=?", status, request.get("id"));
            db.update(paid ? "UPDATE activity SET locked=locked-1,sold=sold+1 WHERE id=?" :
                    "UPDATE activity SET locked=locked-1,available=available+1 WHERE id=?", activity);
            return Map.of("status", status);
        });
    }

    public Map<String, Object> find(String activity, String user) {
        List<Map<String, Object>> rows = db.queryForList("SELECT id,status,expires_at FROM requests WHERE activity_id=? AND user_id=?", activity, user);
        return rows.isEmpty() ? Map.of("status", "NOT_FOUND") : rows.get(0);
    }

    public void expire() {
        for (var row : db.queryForList("SELECT activity_id,user_id FROM requests WHERE status='UNPAID' AND expires_at<=? LIMIT 100", Instant.now().getEpochSecond())) {
            finish(row.get("activity_id").toString(), row.get("user_id").toString(), false);
        }
    }

    private static long number(Map<String, Object> row, String name) { return ((Number) row.get(name)).longValue(); }
}
