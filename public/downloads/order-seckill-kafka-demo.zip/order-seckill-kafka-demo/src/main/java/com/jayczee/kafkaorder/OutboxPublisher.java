package com.jayczee.kafkaorder;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Component
public class OutboxPublisher {
    public static final String TOPIC = "seckill.orders.v1";
    private static final Logger LOG = LoggerFactory.getLogger(OutboxPublisher.class);
    private final JdbcTemplate db;
    private final TransactionTemplate tx;
    private final KafkaTemplate<String, String> kafka;
    private final ObjectMapper json;
    private final Faults faults;

    public OutboxPublisher(JdbcTemplate db, TransactionTemplate tx, KafkaTemplate<String, String> kafka, ObjectMapper json, Faults faults) {
        this.db = db; this.tx = tx; this.kafka = kafka; this.json = json; this.faults = faults;
    }

    @Scheduled(fixedDelay = 100)
    public void publish() {
        if (faults.active("pause-publisher")) return;
        for (int attempt = 0; attempt < 20; attempt++) {
            String owner = UUID.randomUUID().toString();
            Map<String, Object> row = tx.execute(transaction -> {
                long now = Instant.now().getEpochSecond();
                var rows = db.queryForList("SELECT * FROM outbox WHERE delivered=FALSE AND next_attempt<=? AND lease_until<=? ORDER BY id LIMIT 1 FOR UPDATE SKIP LOCKED", now, now);
                if (rows.isEmpty()) return null;
                var claimed = rows.get(0);
                db.update("UPDATE outbox SET lease_owner=?,lease_until=?,attempts=attempts+1 WHERE id=?", owner, now + 30, claimed.get("id"));
                return claimed;
            });
            if (row == null) return;
            try {
                var request = db.queryForMap("SELECT * FROM requests WHERE id=?", row.get("request_id"));
                var event = new OrderEvent(1, ((Number) row.get("id")).longValue(), request.get("id").toString(),
                        request.get("activity_id").toString(), request.get("user_id").toString());
                kafka.send(TOPIC, event.requestId(), json.writeValueAsString(event)).get(12, TimeUnit.SECONDS);
                if (faults.once(event.activityId() + ":crash-publisher")) Runtime.getRuntime().halt(31);
                db.update("UPDATE outbox SET delivered=TRUE,lease_until=0,error_type=NULL WHERE id=? AND lease_owner=?", row.get("id"), owner);
            } catch (Exception exception) {
                db.update("UPDATE outbox SET lease_until=0,next_attempt=?,error_type=? WHERE id=? AND lease_owner=?",
                        Instant.now().getEpochSecond() + 3, exception.getClass().getSimpleName(), row.get("id"), owner);
                LOG.warn("Outbox {} send uncertain: {}", row.get("id"), exception.getClass().getSimpleName());
                return;
            }
        }
    }
}
