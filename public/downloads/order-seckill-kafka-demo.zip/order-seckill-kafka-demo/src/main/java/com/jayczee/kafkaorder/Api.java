package com.jayczee.kafkaorder;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

@RestController
public class Api {
    private final OrderService orders;
    private final JdbcTemplate db;
    private final TransactionTemplate tx;
    private final KafkaTemplate<String, String> kafka;
    private final KafkaListenerEndpointRegistry registry;
    private final String token;

    public Api(OrderService orders, JdbcTemplate db, TransactionTemplate tx, KafkaTemplate<String, String> kafka,
               KafkaListenerEndpointRegistry registry, @Value("${admin_token}") String token) {
        this.orders = orders; this.db = db; this.tx = tx; this.kafka = kafka; this.registry = registry; this.token = token;
    }

    @GetMapping("/health")
    public Map<String, Object> health() {
        db.queryForObject("SELECT 1", Integer.class);
        return Map.of("status", "UP", "instance", System.getenv().getOrDefault("HOSTNAME", "local"));
    }

    @PostMapping("/admin/hello")
    public Map<String, Object> hello(@RequestHeader("X-Admin-Token") String supplied) throws Exception {
        admin(supplied);
        var metadata = kafka.send("hello-kafka", "hello-user", "hello from Java").get(12, TimeUnit.SECONDS).getRecordMetadata();
        return Map.of("topic", metadata.topic(), "partition", metadata.partition(), "offset", metadata.offset());
    }

    @PostMapping("/api/activities/{activity}/buy")
    public ResponseEntity<Map<String, Object>> buy(@PathVariable String activity, @RequestHeader("X-Demo-User") String user) {
        valid(activity); valid(user);
        var result = orders.accept(activity, user);
        int code = switch (result.get("status").toString()) {
            case "QUEUED" -> 202;
            case "NOT_FOUND" -> 404;
            case "SOLD_OUT", "INACTIVE" -> 409;
            case "BUSY" -> 429;
            default -> 200;
        };
        return ResponseEntity.status(code).body(result);
    }

    @GetMapping("/api/orders/{activity}")
    public Map<String, Object> find(@PathVariable String activity, @RequestHeader("X-Demo-User") String user) {
        valid(activity); valid(user); return orders.find(activity, user);
    }

    @PostMapping("/api/orders/{activity}/{action}")
    public Map<String, Object> finish(@PathVariable String activity, @PathVariable String action, @RequestHeader("X-Demo-User") String user) {
        valid(activity); valid(user);
        if (!Set.of("pay", "cancel").contains(action)) throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        return orders.finish(activity, user, action.equals("pay"));
    }

    public record Activity(String id, int stock, int ttlSeconds, int maxPending) {}

    @PostMapping("/admin/activities")
    public Map<String, Object> activity(@RequestHeader("X-Admin-Token") String supplied, @RequestBody Activity activity) {
        admin(supplied); valid(activity.id());
        if (activity.stock() < 1 || activity.stock() > 100000 || activity.ttlSeconds() < 2 || activity.maxPending() < 1 || activity.maxPending() > 10000) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
        }
        long now = Instant.now().getEpochSecond();
        db.update("INSERT INTO activity(id,total,available,ttl_seconds,max_pending,starts_at,ends_at) VALUES(?,?,?,?,?,?,?)",
                activity.id(), activity.stock(), activity.stock(), activity.ttlSeconds(), activity.maxPending(), now, now + 3600);
        return Map.of("status", "READY", "id", activity.id());
    }

    @GetMapping("/admin/activities/{activity}")
    public Map<String, Object> snapshot(@RequestHeader("X-Admin-Token") String supplied, @PathVariable String activity) {
        admin(supplied); valid(activity);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("stock", db.queryForMap("SELECT * FROM activity WHERE id=?", activity));
        result.put("requests", db.queryForList("SELECT status,COUNT(*) AS count FROM requests WHERE activity_id=? GROUP BY status", activity));
        result.put("orders", db.queryForObject("SELECT COUNT(*) FROM orders WHERE activity_id=?", Integer.class, activity));
        result.put("consumers", db.queryForList("SELECT consumer_id,partition_id,COUNT(*) AS count FROM orders WHERE activity_id=? GROUP BY consumer_id,partition_id", activity));
        result.put("outboxPending", db.queryForObject("SELECT COUNT(*) FROM outbox JOIN requests ON requests.id=outbox.request_id WHERE requests.activity_id=? AND delivered=FALSE", Integer.class, activity));
        result.put("sendAttempts", db.queryForObject("SELECT COALESCE(SUM(attempts),0) FROM outbox JOIN requests ON requests.id=outbox.request_id WHERE requests.activity_id=?", Long.class, activity));
        result.put("deliveryAttempts", db.queryForObject("SELECT COALESCE(SUM(attempts),0) FROM delivery_attempt JOIN requests ON requests.id=delivery_attempt.request_id WHERE requests.activity_id=?", Long.class, activity));
        result.put("failed", db.queryForList("SELECT failed_message.* FROM failed_message JOIN requests ON requests.id=failed_message.request_id WHERE requests.activity_id=?", activity));
        return result;
    }

    @GetMapping("/admin/listeners")
    public Map<String, Object> listeners(@RequestHeader("X-Admin-Token") String supplied) {
        admin(supplied);
        var listener = registry.getListenerContainer("order-worker");
        var partitions = listener.getAssignedPartitions();
        return Map.of("instance", System.getenv().getOrDefault("HOSTNAME", "local"), "running", listener.isRunning(),
                "paused", listener.isContainerPaused(), "assignments", partitions == null ? "[]" : partitions.toString());
    }

    public record Fault(String activity, String name, boolean enabled) {}

    @PostMapping("/admin/faults")
    public Map<String, Object> fault(@RequestHeader("X-Admin-Token") String supplied, @RequestBody Fault fault) {
        admin(supplied); valid(fault.activity());
        if (!Set.of("pause-publisher", "pause-consumer", "poison", "slow", "crash-publisher", "crash-consumer").contains(fault.name())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
        String name = fault.name().startsWith("pause-") ? fault.name() : fault.activity() + ":" + fault.name();
        if (fault.enabled()) db.update("INSERT INTO fault(name,expires_at) VALUES(?,?) ON DUPLICATE KEY UPDATE expires_at=VALUES(expires_at)", name, Instant.now().getEpochSecond() + 300);
        else db.update("DELETE FROM fault WHERE name=?", name);
        return Map.of("status", "OK");
    }

    @PostMapping("/admin/activities/{activity}/replay")
    public Map<String, Object> replay(@RequestHeader("X-Admin-Token") String supplied, @PathVariable String activity) {
        admin(supplied); valid(activity);
        int count = tx.execute(transaction -> {
            var rows = db.queryForList("SELECT id FROM requests WHERE activity_id=? AND status='MANUAL_REVIEW' FOR UPDATE", activity);
            for (var row : rows) {
                db.update("UPDATE requests SET status='QUEUED' WHERE id=?", row.get("id"));
                db.update("UPDATE failed_message SET resolved=TRUE WHERE request_id=?", row.get("id"));
                db.update("INSERT INTO outbox(request_id) VALUES(?)", row.get("id"));
            }
            return rows.size();
        });
        return Map.of("replayed", count);
    }

    private void admin(String supplied) {
        if (!MessageDigest.isEqual(token.getBytes(StandardCharsets.UTF_8), supplied.getBytes(StandardCharsets.UTF_8))) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
    }
    private void valid(String value) {
        if (value == null || !value.matches("[a-zA-Z0-9_-]{1,64}")) throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
    }
}
