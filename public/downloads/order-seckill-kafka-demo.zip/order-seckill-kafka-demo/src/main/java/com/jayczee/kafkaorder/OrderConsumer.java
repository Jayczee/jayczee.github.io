package com.jayczee.kafkaorder;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;
import java.time.Duration;

@Component
public class OrderConsumer {
    private final ObjectMapper json;
    private final OrderService orders;
    private final Faults faults;
    private final JdbcTemplate db;
    private final TransactionTemplate tx;
    private final KafkaListenerEndpointRegistry registry;
    private final String instance = System.getenv().getOrDefault("HOSTNAME", "local");

    public OrderConsumer(ObjectMapper json, OrderService orders, Faults faults, JdbcTemplate db,
                         TransactionTemplate tx, KafkaListenerEndpointRegistry registry) {
        this.json = json; this.orders = orders; this.faults = faults; this.db = db; this.tx = tx; this.registry = registry;
    }

    @KafkaListener(id = "order-worker", idIsGroup = false, topics = OutboxPublisher.TOPIC)
    public void consume(ConsumerRecord<String, String> record, Acknowledgment acknowledgment) throws Exception {
        OrderEvent event = json.readValue(record.value(), OrderEvent.class);
        db.update("INSERT INTO delivery_attempt(request_id,attempts) VALUES(?,1) ON DUPLICATE KEY UPDATE attempts=attempts+1", event.requestId());
        if (faults.active(event.activityId() + ":poison")) throw new IllegalStateException("Injected consumer failure");
        if (faults.active(event.activityId() + ":slow")) Thread.sleep(100);
        orders.materialize(event, instance, record.partition(), record.offset());
        if (faults.once(event.activityId() + ":crash-consumer")) Runtime.getRuntime().halt(32);
        acknowledgment.acknowledge();
    }

    @KafkaListener(id = "dlt-worker", topics = OutboxPublisher.TOPIC + ".DLT", groupId = "order-review-v1")
    public void deadLetter(ConsumerRecord<String, String> record, Acknowledgment acknowledgment) {
        try {
            OrderEvent parsed;
            try { parsed = json.readValue(record.value(), OrderEvent.class); } catch (Exception exception) { parsed = null; }
            OrderEvent event = parsed;
            String messageId = event == null ? record.topic() + ":" + record.partition() + ":" + record.offset() : "event:" + event.eventId();
            tx.executeWithoutResult(transaction -> {
                int inserted = db.update("INSERT IGNORE INTO failed_message(message_id,request_id,payload) VALUES(?,?,?)",
                        messageId, event == null ? null : event.requestId(), record.value());
                if (inserted == 1 && event != null) db.update("UPDATE requests SET status='MANUAL_REVIEW' WHERE id=? AND status='QUEUED'", event.requestId());
            });
            acknowledgment.acknowledge();
        } catch (Exception exception) {
            acknowledgment.nack(Duration.ofSeconds(2));
        }
    }

    @Scheduled(fixedDelay = 500)
    public void control() {
        var listener = registry.getListenerContainer("order-worker");
        if (listener == null) return;
        if (faults.active("pause-consumer")) listener.pause();
        else listener.resume();
    }

    @Scheduled(fixedDelay = 1000)
    public void expire() { orders.expire(); }
}
