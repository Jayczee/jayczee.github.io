package com.jayczee.kafkaorder;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import java.time.Instant;

@Component
public class Faults {
    private final JdbcTemplate db;
    public Faults(JdbcTemplate db) { this.db = db; }
    public boolean active(String name) {
        return db.queryForObject("SELECT COUNT(*) FROM fault WHERE name=? AND expires_at>?", Integer.class,
                name, Instant.now().getEpochSecond()) > 0;
    }
    public boolean once(String name) {
        return db.update("DELETE FROM fault WHERE name=? AND expires_at>?", name, Instant.now().getEpochSecond()) == 1;
    }
}
