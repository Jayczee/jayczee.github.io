package com.jayczee.kafkaorder;

public record OrderEvent(int version, long eventId, String requestId, String activityId, String userId) {}
