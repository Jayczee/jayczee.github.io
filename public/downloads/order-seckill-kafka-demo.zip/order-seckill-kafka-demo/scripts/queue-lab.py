from concurrent.futures import ThreadPoolExecutor
import json
import subprocess
import time
from client import ROOT, request, create, snapshot, fault, until, settled

activity = 'queue-' + str(time.time_ns())
create(activity, stock=100, pending=100)
fault(activity, 'pause-consumer', True)


def paused():
    return all(request('/admin/listeners', admin=True, base='http://127.0.0.1:' + str(port))[1].get('paused') for port in (18381, 18382))


def group():
    return subprocess.check_output(['docker', 'compose', 'exec', '-T', 'kafka', '/opt/kafka/bin/kafka-consumer-groups.sh',
                                   '--bootstrap-server', 'kafka:9092', '--describe', '--group', 'order-writer-v1'], cwd=ROOT, text=True)


try:
    until(paused)
    began = time.monotonic()
    with ThreadPoolExecutor(max_workers=12) as pool:
        answers = list(pool.map(lambda user: request('/api/activities/' + activity + '/buy', 'POST', user=user), range(60)))
    assert all(code == 202 for code, _ in answers)
    accepted_seconds = time.monotonic() - began
    until(lambda: snapshot(activity)['outboxPending'] == 0)
    before = snapshot(activity)
    assert before['orders'] == 0 and before['stock']['locked'] == 60
    before_group = group()
finally:
    fault(activity, 'pause-consumer', False)
after = until(lambda: settled(activity))
assert after['orders'] == 60
result = {'accepted': 60, 'admissionSeconds': round(accepted_seconds, 3), 'beforeResume': before,
          'groupBeforeResume': before_group, 'afterDrain': after, 'groupAfterDrain': group()}
(ROOT / 'target/queue-lab.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
