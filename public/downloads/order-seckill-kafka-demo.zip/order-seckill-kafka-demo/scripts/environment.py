import json
import platform
import subprocess


def run(*arguments):
    return subprocess.check_output(arguments, text=True).strip()


report = {
    'system': platform.system(),
    'architecture': platform.machine(),
    'dockerCompose': run('docker', 'compose', 'version', '--short'),
    'java': run('docker', 'compose', 'exec', '-T', 'app1', 'java', '--version'),
    'broker': run('docker', 'compose', 'exec', '-T', 'kafka', '/opt/kafka/bin/kafka-topics.sh', '--version'),
    'mysql': run('docker', 'compose', 'exec', '-T', 'mysql', 'mysql', '--version'),
    'kafkaDigest': run('docker', 'image', 'inspect', 'apache/kafka:4.1.2', '--format', '{{json .RepoDigests}}'),
    'springBoot': '3.5.16', 'springKafka': '3.3.16', 'kafkaClient': '3.9.2',
    'limits': {'appInstances': 2, 'appCpuEach': 1, 'appMemoryMiBEach': 448,
               'brokerCpu': 1, 'brokerMemoryMiB': 1024, 'brokerHeapMiB': 512,
               'mysqlCpu': 1, 'mysqlMemoryMiB': 640},
    'layout': 'Single NAS, single KRaft combined broker/controller, replication factor 1. Other unrelated services share the host.',
    'coverage': 'Functional correctness and crash recovery, not a throughput or multi-node failover benchmark.'
}
print(json.dumps(report, indent=2))
