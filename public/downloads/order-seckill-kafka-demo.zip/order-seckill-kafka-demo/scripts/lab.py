import argparse
import json
from client import create, snapshot, request, fault

parser = argparse.ArgumentParser()
parser.add_argument('action', choices=['create', 'snapshot', 'hello', 'fault', 'replay', 'listeners'])
parser.add_argument('activity', nargs='?', default='manual')
parser.add_argument('--stock', type=int, default=100)
parser.add_argument('--pending', type=int, default=1000)
parser.add_argument('--ttl', type=int, default=300)
parser.add_argument('--name')
parser.add_argument('--enabled', action='store_true')
args = parser.parse_args()
if args.action == 'create':
    create(args.activity, stock=args.stock, ttl=args.ttl, pending=args.pending)
    result = snapshot(args.activity)
elif args.action == 'snapshot':
    result = snapshot(args.activity)
elif args.action == 'fault':
    fault(args.activity, args.name, args.enabled)
    result = {'status': 'OK'}
elif args.action == 'replay':
    result = request('/admin/activities/' + args.activity + '/replay', 'POST', admin=True)
elif args.action == 'listeners':
    result = [request('/admin/listeners', admin=True, base='http://127.0.0.1:' + str(port)) for port in (18381, 18382)]
else:
    result = request('/admin/hello', 'POST', admin=True)
print(json.dumps(result, ensure_ascii=False, indent=2))
