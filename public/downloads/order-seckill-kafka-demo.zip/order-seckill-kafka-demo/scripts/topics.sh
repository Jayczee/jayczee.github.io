#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
for topic in hello-kafka seckill.orders.v1 seckill.orders.v1.DLT; do
  partitions=3
  if [ "$topic" = hello-kafka ]; then partitions=1; fi
  docker compose exec -T kafka /opt/kafka/bin/kafka-topics.sh \
    --bootstrap-server kafka:9092 --create --if-not-exists \
    --topic "$topic" --partitions "$partitions" --replication-factor 1 \
    --config min.insync.replicas=1 --config retention.ms=86400000
done
docker compose exec -T kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server kafka:9092 --describe --topic seckill.orders.v1
