from concurrent.futures import ThreadPoolExecutor
import json
import subprocess
import time
from client import ROOT, request, create, snapshot, fault, until, settled

prefix = 'verify-' + str(time.time_ns())
results = {}


def compose(*arguments):
    return subprocess.check_output(['docker', 'compose', *arguments], cwd=ROOT, text=True)


def buy(activity, user):
    return request(f'/api/activities/{activity}/buy', 'POST', user=user)


def status(activity, user):
    return request('/api/orders/' + activity, user=user)[1]['status']


def ready():
    return all(request('/admin/listeners', admin=True, base='http://127.0.0.1:' + str(port))[1].get('assignments', '[]') != '[]' for port in (18381, 18382))


until(ready)
assert request('/admin/hello', 'POST', admin=True)[0] == 200
results['hello-message'] = 'published with broker metadata'
activity = prefix + '-stock'
create(activity)
with ThreadPoolExecutor(max_workers=24) as pool:
    answers = list(pool.map(lambda user: buy(activity, user), range(300)))
assert all(code in (200, 202, 409) for code, _ in answers), answers
state = until(lambda: settled(activity))
assert state['orders'] == 100 and state['stock']['locked'] == 100
assert len({row['consumer_id'] for row in state['consumers']}) == 2
assert len({row['partition_id'] for row in state['consumers']}) == 3
results['300-for-100-two-consumers-three-partitions'] = state
winners = [str(user) for user, (code, _) in enumerate(answers) if code in (200, 202)]
with ThreadPoolExecutor(max_workers=20) as pool:
    list(pool.map(lambda pair: request(f'/api/orders/{activity}/' + ('pay' if pair[0] < 50 else 'cancel'), 'POST', user=pair[1]), enumerate(winners)))
results['pay-50-cancel-50'] = until(lambda: settled(activity))
assert results['pay-50-cancel-50']['stock']['sold'] == 50
assert results['pay-50-cancel-50']['stock']['available'] == 50

activity = prefix + '-duplicate'
create(activity, stock=5)
with ThreadPoolExecutor(max_workers=20) as pool:
    answers = list(pool.map(lambda _: buy(activity, 'same'), range(60)))
assert len({body['id'] for _, body in answers}) == 1
assert until(lambda: settled(activity))['orders'] == 1
with ThreadPoolExecutor(max_workers=20) as pool:
    list(pool.map(lambda index: request(f'/api/orders/{activity}/' + ('pay' if index % 2 else 'cancel'), 'POST', user='same'), range(30)))
results['duplicate-and-pay-cancel-race'] = until(lambda: settled(activity))
assert results['duplicate-and-pay-cancel-race']['stock']['locked'] == 0

activity = prefix + '-bound'
create(activity, stock=20, pending=5)
fault(activity, 'pause-publisher', True)
try:
    time.sleep(1)
    answers = [buy(activity, str(index)) for index in range(20)]
    assert sum(code == 202 for code, _ in answers) == 5
    assert sum(code == 429 for code, _ in answers) == 15
    results['outbox-bound'] = snapshot(activity)
finally:
    fault(activity, 'pause-publisher', False)
assert until(lambda: settled(activity))['orders'] == 5

activity = prefix + '-publisher'
create(activity, stock=1)
fault(activity, 'crash-publisher', True)
assert buy(activity, 'publisher')[0] == 202
results['broker-ack-before-outbox-mark-crash'] = until(lambda: settled(activity))
assert results['broker-ack-before-outbox-mark-crash']['orders'] == 1
assert results['broker-ack-before-outbox-mark-crash']['sendAttempts'] >= 2
until(ready)

activity = prefix + '-consumer'
create(activity, stock=1)
fault(activity, 'crash-consumer', True)
assert buy(activity, 'consumer')[0] == 202
until(lambda: snapshot(activity)['deliveryAttempts'] >= 2)
until(ready)
time.sleep(3)
results['db-commit-before-offset-crash'] = until(lambda: settled(activity))
assert results['db-commit-before-offset-crash']['orders'] == 1

activity = prefix + '-poison'
create(activity, stock=1)
fault(activity, 'poison', True)
assert buy(activity, 'poison')[0] == 202
until(lambda: status(activity, 'poison') == 'MANUAL_REVIEW')
results['dead-letter'] = snapshot(activity)
assert results['dead-letter']['orders'] == 0 and len(results['dead-letter']['failed']) == 1
fault(activity, 'poison', False)
assert request('/admin/activities/' + activity + '/replay', 'POST', admin=True)[1]['replayed'] == 1
results['dead-letter-replay'] = until(lambda: settled(activity))
assert results['dead-letter-replay']['orders'] == 1
assert request('/admin/activities/' + activity + '/replay', 'POST', admin=True)[1]['replayed'] == 0

activity = prefix + '-expiry'
create(activity, stock=1, ttl=2)
assert buy(activity, 'expire')[0] == 202
until(lambda: status(activity, 'expire') == 'CANCELLED')
results['expiry'] = until(lambda: settled(activity))
assert results['expiry']['stock']['available'] == 1

activity = prefix + '-broker-down'
create(activity, stock=3)
compose('stop', 'kafka')
try:
    assert buy(activity, 'offline')[0] == 202
    time.sleep(15)
    state = snapshot(activity)
    assert state['outboxPending'] == 1 and state['orders'] == 0
    results['broker-down-persisted-acceptance'] = state
finally:
    compose('start', 'kafka')
results['broker-restart-recovery'] = until(lambda: settled(activity), timeout=180)
assert results['broker-restart-recovery']['orders'] == 1

results['group-after-recovery'] = compose('exec', '-T', 'kafka', '/opt/kafka/bin/kafka-consumer-groups.sh', '--bootstrap-server', 'kafka:9092', '--describe', '--group', 'order-writer-v1')
(ROOT / 'target').mkdir(exist_ok=True)
(ROOT / 'target/verification.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
print('PASS:', ', '.join(results))
