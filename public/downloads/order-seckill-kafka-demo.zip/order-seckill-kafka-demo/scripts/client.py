import json
import os
from pathlib import Path
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
BASE = os.environ.get('DEMO_URL', 'http://127.0.0.1:18380')
TOKEN = (ROOT / 'secrets/admin_token').read_text().strip()


def request(path, method='GET', data=None, user='test', admin=False, base=None):
    headers = {'Content-Type': 'application/json', 'X-Demo-User': str(user)}
    if admin:
        headers['X-Admin-Token'] = TOKEN
    call = urllib.request.Request((base or BASE) + path, data=json.dumps(data).encode() if data is not None else (b'' if method == 'POST' else None), headers=headers, method=method)
    try:
        with urllib.request.urlopen(call, timeout=18) as response:
            return response.status, json.load(response)
    except urllib.error.HTTPError as error:
        try:
            body = json.load(error)
        except (ValueError, UnicodeDecodeError):
            body = {'status': 'HTTP_ERROR'}
        return error.code, body


def create(activity, stock=100, ttl=3600, pending=1000):
    code, body = request('/admin/activities', 'POST', dict(id=activity, stock=stock, ttlSeconds=ttl, maxPending=pending), admin=True)
    assert code == 200, (code, body)


def snapshot(activity):
    code, body = request('/admin/activities/' + activity, admin=True)
    assert code == 200, (code, body)
    return body


def fault(activity, name, enabled):
    assert request('/admin/faults', 'POST', dict(activity=activity, name=name, enabled=enabled), admin=True)[0] == 200


def until(check, timeout=120):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            result = check()
            if result:
                return result
        except (OSError, ValueError, AssertionError):
            pass
        time.sleep(.3)
    raise AssertionError('Timed out waiting for expected state')


def settled(activity):
    state = snapshot(activity)
    counts = {row['status']: row['count'] for row in state['requests']}
    if state['outboxPending'] or counts.get('QUEUED', 0) or counts.get('MANUAL_REVIEW', 0):
        return False
    stock = state['stock']
    assert stock['available'] + stock['locked'] + stock['sold'] == stock['total']
    assert min(stock['available'], stock['locked'], stock['sold']) >= 0
    assert stock['locked'] == counts.get('UNPAID', 0)
    assert stock['sold'] == counts.get('PAID', 0)
    assert state['orders'] == sum(counts.get(status, 0) for status in ('UNPAID', 'PAID', 'CANCELLED'))
    return state
