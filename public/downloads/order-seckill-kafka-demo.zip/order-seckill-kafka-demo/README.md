# order-seckill-kafka-demo

[配套博文：给秒杀系统接上 Kafka：从第一条消息到可靠落单](https://jayczee.cn/posts/order-seckill-kafka-demo/)

秒杀项目的 Kafka 接入实验。沿用 order-seckill-demo 的库存与订单模型，但本项目不依赖 Redis，也不保留 Redis Stream。采用 MySQL 受理事务 + outbox + Kafka + 幂等落单。

这不是上一版的性能升级承诺：受理环节仍要写 MySQL，Kafka 隔离的是后续任务的执行节奏。单节点部署用于学习、联调和进程重启恢复，不验证多节点容灾。

## 启动

需要 JDK 17+、Maven 3.9、Docker Compose v2、Python 3、OpenSSL，建议至少 4 GiB 空闲内存。版本：Spring Boot 3.5.16 / Spring Kafka 3.3.16 / Kafka Java client 3.9.2 / broker apache/kafka:4.1.2 / MySQL 8.0.41。Java 客户端和 broker 不要求版本号相同，本例使用 Boot 管理的依赖并验证实际调用。

先获取源码：

```bash
git clone https://github.com/Jayczee/order-seckill-kafka-demo.git
cd order-seckill-kafka-demo
```

在项目根目录执行：

```bash
bash scripts/init-secrets.sh
docker compose up -d mysql kafka
docker compose ps
bash scripts/topics.sh
mvn -B -ntp package
docker compose up -d --build app1 app2 gateway
curl http://127.0.0.1:18380/health
```

先等 MySQL、Kafka healthy 再执行后续命令。topics.sh 创建单分区 hello-kafka，以及三个分区的 seckill.orders.v1 和对应 DLT；均为单副本。禁止 broker 自动建 topic，避免拼错名字也自动生成。

`/health` 只验证 Java 与 MySQL，不验证 Kafka 的端到端消息链路；后续通过 hello、lag 和真实订单验证。刚启动出现 502 时等 Java 完成启动，并看 `docker compose logs --tail=60 app1 app2`。

两个 Java 实例用同一个 jar，生产者、消费者、API 都在里面。为了把实验做小，没有拆成多个部署项目；正式环境可以按扩缩容需要拆 producer 与 consumer。HTTP 入口 18380，直接调试两个实例用 18381/18382，默认均只监听本机。

## 发第一条消息

```bash
printf 'first message\n' | docker compose exec -T kafka /opt/kafka/bin/kafka-console-producer.sh --bootstrap-server kafka:9092 --topic hello-kafka
docker compose exec -T kafka /opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server kafka:9092 --topic hello-kafka --from-beginning --max-messages 1 --property print.partition=true --property print.offset=true
python3 scripts/lab.py hello
```

Python 调用 Java 的 KafkaTemplate 发送消息，打印 broker 返回的 topic、partition、offset；不是正式订单。再次从 beginning 消费最早一条仍可能是 first message，Kafka 不因被读取就删除消息。

## 创建订单

```bash
python3 scripts/lab.py create first-order --stock 100
curl -X POST http://127.0.0.1:18380/api/activities/first-order/buy -H 'X-Demo-User: user-1'
curl http://127.0.0.1:18380/api/orders/first-order -H 'X-Demo-User: user-1'
python3 scripts/lab.py snapshot first-order
curl -X POST http://127.0.0.1:18380/api/orders/first-order/pay -H 'X-Demo-User: user-1'
```

也可打开 http://127.0.0.1:18380 ，输入本机 secrets/admin_token 创建活动。不要分享令牌，管理接口可以触发实验进程退出。X-Demo-User 仅用于模拟身份，正式系统应从认证上下文取用户。

新受理返回 202 QUEUED，表示 MySQL 已记录申请和待发送任务，不代表 Kafka 已收到，更不代表订单已完成。消费者落单后变为 UNPAID；付款后 PAID，取消或超时后 CANCELLED。消费持续失败进入 MANUAL_REVIEW。每人每活动限一件，取消后也不重复参与。只有 UNPAID 可支付/取消，QUEUED/MANUAL_REVIEW 不直接释放库存以免与在途任务冲突。MANUAL_REVIEW 需修复重放，暂不提供撤销待处理资格的流程。

库存口径：available + locked + sold = total；本版 locked 包括 QUEUED、MANUAL_REVIEW、UNPAID，不再只代表待付款订单。受理已经扣减库存，消费者不能再扣一次。

## 连接 NAS

容器内应用连接 kafka:9092。外部客户端默认连接 localhost:19092。Kafka 会返回 advertised.listeners 中的地址，能连 bootstrap 不代表能连返回的 broker 地址。

在 NAS 上可以保留默认回环映射，用 SSH 转发本机 19092 到 NAS 的 127.0.0.1:19092，此时 advertised localhost 正确对应转发入口。只给单 broker 开一个隧道适用于本单节点实验，不代表多 broker 也只要转发一个端口。

如需局域网直接访问，在 NAS 项目目录创建被忽略的 .env，设置 KAFKA_BIND_IP 为 NAS 的具体内网接口 IP，KAFKA_EXTERNAL_HOST 为电脑可访问的 NAS 内网地址。然后重新创建 Kafka 容器，使用电脑访问 EXTERNAL 地址。不要发布到公网；当前 PLAINTEXT 无认证无加密，多用户/跨信任边界环境应使用 SASL_SSL 与 ACL。数据库密码仅保存在本地 secrets 中。凭证文件目录设为 0700，单个文件为 0644 以供非 root 应用容器通过独立 bind mount 读取。

## 验证

```bash
python3 scripts/verify.py
python3 scripts/queue-lab.py
```

verify 会在这个独立 Compose 项目内故意退出生产者/消费者进程、停止并重启 Kafka，不操作其他项目。Docker 自动重启应用，脚本 finally 重启 Kafka。不要在生产环境运行，不要与手动操作或另一个脚本并行。

全部断言通过才保存 target/verification.json。覆盖 300 人抢 100 件、两消费者三分区、重复申请、支付取消、积压上限、broker 确认后 publisher 退出、DB 提交后 consumer 退出、DLT 与人工重放、超时、Kafka 停机后 outbox 补发。

queue-lab 暂停订单消费者，受理 60 条任务并等发送完，观察 Kafka lag 与数据库待办；恢复消费后对账。保存 target/queue-lab.json。这是积压演示，不是 QPS 基准。

2026-09-16 在 NAS Docker 中实际完成这两组脚本，原始记录位于 evidence/。暂停后 lag 22/19/19、正式订单 0；恢复后 lag 全部为 0、订单 60。故障测试确认生产者重复发送、消费者重复消费后，正式订单和库存仍然唯一。

```bash
python3 scripts/lab.py listeners
docker compose exec -T kafka /opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server kafka:9092 --describe --group order-writer-v1
```

## 故障开关

```bash
python3 scripts/lab.py fault first-order --name pause-consumer --enabled
python3 scripts/lab.py fault first-order --name pause-consumer
python3 scripts/lab.py fault first-order --name poison --enabled
python3 scripts/lab.py fault first-order --name poison
python3 scripts/lab.py replay first-order
```

- pause-consumer / pause-publisher 对整个实验有效；其余故障只对活动有效。
- poison 在落单前抛异常；首次失败后重试两次，仍失败才写 DLT。
- crash-publisher：Kafka 确认后、outbox 标记前退出一次，租约到期后重复发送。
- crash-consumer：MySQL 提交后、offset 提交前退出一次，重新消费但不重复落单。
- slow：每条订单处理前延迟 100ms，用于观察 lag。

开关 300 秒后失效。replay 只重放 MANUAL_REVIEW 的请求，并事务内标记原失败记录 resolved；不是全组 reset offset，不会重新消费所有用户。修复失败原因后再重放。

## 代码入口

- OrderService：受理、幂等落单、支付取消。事务受理保证库存、请求、outbox 一起提交。
- OutboxPublisher：短事务领取待办，发送期间不持有数据库行锁。30 秒租约、发送最多等待 12 秒；失败或结果不确定都重试，不释放库存。
- KafkaConfig：发送确认 DLT 后才推进原消息进度；DLT 失败继续保留原任务重试。
- OrderConsumer：MySQL 提交后手动 acknowledge；DLT 写入失败记录。DLT 写数据库失败时 nack，不再递归扔进 DLT.DLT。
- Api：创建活动、快照、hello、查询、实验开关与重放。

## 限制

- 单 broker、单副本，acks=all 也不是高可用。生产通常需要多故障域 broker、副本 3、min.insync.replicas=2，独立的奇数 controller quorum，TLS/ACL 和监控。不能只把副本数改成 3 就声称单节点变生产集群。
- 本例使用静态 KRaft quorum 明确固定节点关系，不使用 ZooKeeper。新集群的动态 quorum、扩缩容与升级应按选定 Kafka 版本文档实施。
- 幂等 producer 处理客户端内部发送重试，无法消除 outbox 补发的业务重复。Kafka 与 MySQL 不是一个事务。
- 示例 outbox 顺序逐条发送，方便观察确认点，不是高吞吐批量发送器。maxPending 检查会扫描本活动待处理申请，教学规模之外需要更高效的容量计数方案。
- 使用 requestId 作为 key，分散同一活动的不同订单；只保证同分区日志顺序，不保证整个活动全局顺序。重试/DLT 重放还会改变业务完成顺序。
- retention 的时间/字节上限是日志清理规则，不会等所有消费组处理完。超过保留窗口需要核对 MySQL 受理记录并受控补发，当前不提供自动补发已标记发送、却过期未消费的消息。
- offset lag=0 不等于所有业务成功，DLT 转移也会推进原 topic 的进度。监控 outboxPending、QUEUED、MANUAL_REVIEW、DLT 与订单账。
- Kafka 短停仍允许受理，直到本活动 maxPending 或库存耗尽；不是无界缓冲，也没有跨活动总量限流。上线还要入口限流、故障熔断和队列时限。
- 未提供真正支付、登录、防机器人、多机容灾或正式吞吐结论。mvn package 是编译打包，业务验证执行 Python 集成脚本。

## 清理

```bash
docker compose down
```

保留具名卷与 secrets，便于复查。确认数据可丢弃时才使用 down -v，不能只删密码再复用旧 MySQL 数据卷。
