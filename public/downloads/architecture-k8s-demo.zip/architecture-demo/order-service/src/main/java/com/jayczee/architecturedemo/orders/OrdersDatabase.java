package com.jayczee.architecturedemo.orders;

import com.jayczee.architecturedemo.support.Database;
import java.util.LinkedHashMap;
import java.util.Map;

public final class OrdersDatabase extends Database {
    public OrdersDatabase() throws Exception {
        super("amdemo_orders");
        jdbc.execute("""
                create table if not exists orders (
                    request_id varchar(80) primary key, user_id bigint not null,
                    sku varchar(40) not null, quantity int not null,
                    status varchar(24) not null, amount_fen bigint not null
                ) engine=InnoDB
                """);
        jdbc.execute("""
                create table if not exists outbox (
                    request_id varchar(80) not null, kind varchar(12) not null,
                    status varchar(12) not null, attempts int not null default 0,
                    last_error varchar(200) not null default '',
                    primary key (request_id, kind)
                ) engine=InnoDB
                """);
    }

    @Override
    public void reset() {
        transaction(() -> {
            jdbc.update("delete from orders");
            jdbc.update("delete from outbox");
            return null;
        });
    }

    @Override
    public Map<String, Object> snapshot() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("orders", jdbc.queryForList("select * from orders order by request_id"));
        result.put("events", jdbc.queryForList("select * from outbox order by request_id,kind"));
        return result;
    }
}
