package com.jayczee.architecturedemo.orders;

import com.jayczee.architecturedemo.support.ApiErrors;
import com.jayczee.architecturedemo.support.Faults;
import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

@EnableDubbo
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
@Import({ApiErrors.class, Faults.class})
public class OrdersApplication {
    public static void main(String[] args) { SpringApplication.run(OrdersApplication.class, args); }

    @Bean(destroyMethod = "close")
    OrdersDatabase database() throws Exception { return new OrdersDatabase(); }

    @Bean
    Orders orders(OrdersDatabase database, RemoteGateway remote) { return new Orders(database, remote); }
}
