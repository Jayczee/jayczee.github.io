package com.jayczee.architecturedemo.orders;

import com.jayczee.architecturedemo.support.BusinessConflict;

import java.util.Map;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;

public final class Orders {
    private final OrdersDatabase database;
    private final RemoteGateway remote;
    private final Semaphore workers = new Semaphore(2);
    final AtomicInteger busy = new AtomicInteger();
    final AtomicInteger maxBusy = new AtomicInteger();

    Orders(OrdersDatabase database, RemoteGateway remote) {
        this.database = database;
        this.remote = remote;
    }

    public Map<String, Object> place(String requestId, long userId, String sku, int quantity) {
        return database.transaction(() -> {
            database.jdbc.update("""
                    insert into orders values (?, ?, ?, ?, 'NEW', ?)
                    on duplicate key update request_id=request_id
                    """, requestId, userId, sku, quantity, quantity * 1000L);
            Map<String, Object> row = locked(requestId);
            if (!sku.equals(row.get("sku")) || userId != ((Number) row.get("user_id")).longValue()
                    || quantity != ((Number) row.get("quantity")).intValue()) {
                throw new BusinessConflict("order request payload changed");
            }
            if (!row.get("status").equals("NEW")) return row;
            enqueue(requestId, "RESERVE", "PENDING");
            return find(requestId);
        });
    }

    public Map<String, Object> transition(String requestId, String kind) {
        return database.transaction(() -> {
            Map<String, Object> row = locked(requestId);
            String current = (String) row.get("status");
            String finished = kind.equals("PAY") ? "PAID" : "CANCELLED";
            String pending = kind + "_PENDING";
            if (current.equals(finished) || current.equals(pending)) return row;
            if (!current.equals("RESERVED")) throw new BusinessConflict("order is " + current);
            enqueue(requestId, kind, pending);
            return find(requestId);
        });
    }

    private void enqueue(String requestId, String kind, String state) {
        status(requestId, state);
        database.jdbc.update("insert into outbox(request_id,kind,status) values (?,?,'PENDING')", requestId, kind);
    }

    public Map<String, Object> drain() {
        if (!workers.tryAcquire()) return Map.of("processed", 0, "busy", true);
        int active = busy.incrementAndGet();
        maxBusy.accumulateAndGet(active, Math::max);
        try {
            var candidates = database.jdbc.queryForList(
                    "select request_id,kind from outbox where status='PENDING' order by request_id,kind limit 1");
            if (candidates.isEmpty()) return Map.of("processed", 0);
            Map<String, Object> event = candidates.get(0);
            return database.transaction(() -> {
                String requestId = (String) event.get("request_id");
                String kind = (String) event.get("kind");
                Map<String, Object> row = locked(requestId);
                Map<String, Object> message = database.jdbc.queryForMap(
                        "select * from outbox where request_id=? and kind=? for update", requestId, kind);
                if (!message.get("status").equals("PENDING")) return Map.of("processed", 0);
                try {
                    Map<String, Object> payload = Map.of("requestId", requestId, "sku", row.get("sku"),
                            "quantity", row.get("quantity"), "amountFen", row.get("amount_fen"));
                    if (kind.equals("PAY")) remote.send("payment", "/charge", payload);
                    String action = switch (kind) {
                        case "PAY" -> "/confirm";
                        case "CANCEL" -> "/release";
                        default -> "/reserve";
                    };
                    remote.send("inventory", action, payload);
                    String finished = switch (kind) {
                        case "PAY" -> "PAID";
                        case "CANCEL" -> "CANCELLED";
                        default -> "RESERVED";
                    };
                    status(requestId, finished);
                    database.jdbc.update("update outbox set status='DONE',last_error='' where request_id=? and kind=?",
                            requestId, kind);
                    return Map.of("processed", 1, "requestId", requestId, "status", finished);
                } catch (Exception failure) {
                    int attempts = ((Number) message.get("attempts")).intValue() + 1;
                    boolean rejected = failure instanceof BusinessConflict;
                    String eventStatus = attempts >= 5 || rejected ? "FAILED" : "PENDING";
                    if (rejected && kind.equals("RESERVE")) status(requestId, "REJECTED");
                    database.jdbc.update("""
                            update outbox set status=?, attempts=?, last_error=?
                            where request_id=? and kind=?
                            """, eventStatus, attempts, rejected ? "business conflict" : "remote outcome unknown", requestId, kind);
                    return Map.of("processed", 0, "requestId", requestId, "eventStatus", eventStatus, "attempts", attempts);
                }
            });
        } finally {
            busy.decrementAndGet();
            workers.release();
        }
    }

    public Map<String, Object> find(String requestId) {
        return database.jdbc.queryForMap("select * from orders where request_id=?", requestId);
    }

    private Map<String, Object> locked(String requestId) {
        return database.jdbc.queryForMap("select * from orders where request_id=? for update", requestId);
    }

    private void status(String requestId, String state) {
        database.jdbc.update("update orders set status=? where request_id=?", state, requestId);
    }
}
