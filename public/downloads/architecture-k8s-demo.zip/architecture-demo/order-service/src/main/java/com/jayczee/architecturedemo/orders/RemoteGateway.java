package com.jayczee.architecturedemo.orders;

import com.jayczee.architecturedemo.support.BusinessConflict;

import com.jayczee.architecturedemo.api.InventoryRpc;
import com.jayczee.architecturedemo.api.PaymentRpc;
import java.util.Map;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Component;

@Component
public class RemoteGateway {
    @DubboReference(version = "1.0.0", group = "architecture-demo", timeout = 800, retries = 0, check = false, lazy = true)
    private InventoryRpc inventory;

    @DubboReference(version = "1.0.0", group = "architecture-demo", timeout = 800, retries = 0, check = false, lazy = true)
    private PaymentRpc payment;

    Map<String, Object> probe() {
        return Map.of("inventory", inventory.ping(), "payment", payment.ping(), "transport", "dubbo");
    }

    void send(String service, String path, Map<String, Object> body) {
        String requestId = (String) body.get("requestId");
        String result = service.equals("payment")
                ? payment.charge(requestId, ((Number) body.get("amountFen")).longValue())
                : inventory.apply(path.substring(1), requestId, (String) body.get("sku"),
                        ((Number) body.get("quantity")).intValue());
        System.out.printf("request=%s peer=%s transport=dubbo action=%s result=%s%n", requestId, service, path, result);
        if (result.startsWith("CONFLICT:")) throw new BusinessConflict(result.substring(9));
        if (!result.equals("OK")) throw new IllegalStateException("remote unavailable");
    }
}
