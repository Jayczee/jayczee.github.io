package com.jayczee.architecturedemo.orders;

import java.util.Map;
import com.jayczee.architecturedemo.support.Input;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class OrderController {
    private final Orders orders;
    private final RemoteGateway remote;

    public OrderController(Orders orders, RemoteGateway remote) {
        this.orders = orders;
        this.remote = remote;
    }

    @GetMapping("/orders/{requestId}")
    public Object find(@PathVariable String requestId) { return orders.find(requestId); }

    @PostMapping("/orders")
    public ResponseEntity<?> place(@RequestBody Map<String, Object> body) {
        String requestId = Input.text(body, "requestId");
        String sku = Input.text(body, "sku");
        int quantity = Input.quantity(body);
        long userId = Input.number(body, "userId");
        if (userId < 1 || sku.length() > 40) throw new IllegalArgumentException("invalid user or sku");
        Object result = orders.place(requestId, userId, sku, quantity);
        return ResponseEntity.status(202).body(result);
    }

    @PostMapping({"/pay", "/cancel"})
    public ResponseEntity<?> transition(@RequestBody Map<String, Object> body, jakarta.servlet.http.HttpServletRequest request) {
        Object result = orders.transition(Input.text(body, "requestId"), request.getRequestURI().equals("/pay") ? "PAY" : "CANCEL");
        return ResponseEntity.status(202).body(result);
    }

    @PostMapping("/drain")
    public Object drain() { return orders.drain(); }

    @GetMapping("/rpc-health")
    public Object rpcHealth() { return remote.probe(); }
}
