package com.jayczee.architecturedemo.orders;

import com.jayczee.architecturedemo.support.AdminEndpoints;
import com.jayczee.architecturedemo.support.Faults;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController extends AdminEndpoints {
    private final Orders orders;

    public AdminController(OrdersDatabase database, Faults faults, Environment environment, Orders orders) {
        super("orders", database, faults, environment);
        this.orders = orders;
    }

    @Override
    @GetMapping("/metrics")
    public Map<String, Object> metrics() {
        Map<String, Object> result = super.metrics();
        result.put("workersBusy", orders.busy.get());
        result.put("workersMax", orders.maxBusy.get());
        return result;
    }
}
