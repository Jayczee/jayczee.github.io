# Kubernetes 入门实验

从 Docker Compose 到 Kubernetes 的配套文件。先部署 hello，再部署订单、库存、支付、网关。原有 Compose 项目不需要停止。

## 工具

Docker、kind v0.33.0、kubectl v1.35.8、Python 3、OpenSSL；构建业务项目需要 JDK17、Maven。节点镜像为 kindest/node:v1.35.8，脚本已固定摘要。建议为 Docker 留出4核、6GiB可用内存和10GiB磁盘。

在工程根目录运行：

```bash
bash k8s/scripts/create-cluster.sh
export KUBECONFIG="$PWD/target/kubeconfig"
k() { kubectl --context kind-architecture-lab -n order-lab "$@"; }

docker build --build-arg APP_VERSION=v1 -t architecture-hello:v1 k8s/hello
docker build --build-arg APP_VERSION=v2 -t architecture-hello:v2 k8s/hello
kind load docker-image --name architecture-lab architecture-hello:v1 architecture-hello:v2
k apply -f k8s/hello/
k rollout status deployment/hello --timeout=120s
k port-forward service/hello 18088:80 --address=127.0.0.1
```

另一终端 curl http://127.0.0.1:18088/。新增终端都要重新 export KUBECONFIG 和定义 k。port-forward选定一个Pod，不适合证明Service负载均衡；从集群内访问hello:80验证。

## 业务环境

```bash
bash k8s/scripts/infra.sh
bash k8s/scripts/build-images.sh
bash k8s/scripts/deploy-apps.sh
```

infra.sh创建专用MySQL/Nacos容器、具名卷和secrets/k8s_mysql_password，不修改原Compose服务或凭证。两个基础设施容器接入kind网络；用无selector的Service和EndpointSlice把容器地址提供给Pod。重建基础设施容器后重新运行infra.sh刷新IP；它也恢复Nacos默认教学配置。

三项业务服务挂载mysql-auth Secret为文件，网关不挂载。示例共用实验MySQL root账号；不提供生产级授权、网络策略、Nacos鉴权或Secret静态加密。

业务密码挂载到/run/app-secrets，避免只读覆盖/run/secrets后与/var/run/secrets/kubernetes.io/serviceaccount冲突。所有实验应用不调用Kubernetes API，因此禁用automountServiceAccountToken；需要调用API的应用应单独配置最小权限。

四个应用的/health只证明HTTP进程已就绪，不能代替真实DB/RPC验证。分别在两个终端转发gateway:8080到18180、orders:8080到18183：

```bash
k port-forward service/gateway 18180:8080 --address=127.0.0.1
k port-forward service/orders 18183:8080 --address=127.0.0.1
```

如果端口已被原Compose占用，改用空闲端口。查询orders的/rpc-health确认Dubbo，再参照根README的/api/orders、/api/pay和/drain完成业务。Pod替换后，相应port-forward可能断开，需要重启。

## 验证

```bash
python3 k8s/scripts/verify.py
```

脚本操作的context固定为kind-architecture-lab，namespace固定为order-lab。它重置专用实验表、替换hello镜像、删除hello Pod、重启orders，并启动28180/28183/28184/28185本地转发。不要并发运行，不要在这些示例库中存放要保留的数据。全部断言通过才写target/k8s-results.json，留下k8s-review已支付订单。无自动真实支付或外部扣款。

覆盖Pod重建、真实Service请求、readiness端点、v2更新、错误镜像回滚、网关+Dubbo订单支付、订单Pod重建后数据保留。不会证明多节点容灾或业务滚动发布完全无损。

2026-09-14在Linux amd64、kind v0.33.0、Kubernetes v1.35.8上完整通过，原始结果见verification-2026-09-14.json。该次运行复用了此前验证过的应用镜像，并重新打标签加载到kind；hello v1/v2由本目录源码重新构建。业务最终PAID、库存98/0/2、支付一条；所有Pod在清理前Ready。

## 清理

先结束本地port-forward，再运行：

```bash
docker compose -f k8s/infra/compose.yaml down
kind delete cluster --name architecture-lab
```

down不带-v，专用MySQL/Nacos卷保留。不要删除密码文件后复用数据库卷。kind集群内资源将被删除；kubeconfig也是凭证，位于Git忽略的target下。
