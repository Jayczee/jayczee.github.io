#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
export KUBECONFIG="$PWD/target/kubeconfig"
kubectl --context kind-architecture-lab get namespace order-lab >/dev/null
mkdir -p secrets
chmod 700 secrets
if [ ! -s secrets/k8s_mysql_password ]; then
  (umask 077; openssl rand -hex 24 > secrets/k8s_mysql_password)
fi
docker compose -f k8s/infra/compose.yaml up -d --wait
kubectl --context kind-architecture-lab -n order-lab create secret generic mysql-auth \
  --from-file=mysql_password=secrets/k8s_mysql_password --dry-run=client -o json |
  kubectl --context kind-architecture-lab apply -f -
python3 k8s/scripts/bridge-infra.py | kubectl --context kind-architecture-lab apply -f -
for service in orders inventory payment; do
  docker compose -f k8s/infra/compose.yaml exec -T nacos curl -fsS \
    -X POST http://127.0.0.1:8848/nacos/v1/cs/configs \
    --data-urlencode "dataId=$service.yaml" --data-urlencode "group=ARCH_DEMO" \
    --data-urlencode "type=yaml" --data-urlencode "content=demo:
  message: nacos-$service-v1"
done
docker compose -f k8s/infra/compose.yaml exec -T nacos curl -fsS \
  -X POST http://127.0.0.1:8848/nacos/v1/cs/configs \
  --data-urlencode "dataId=inventory-flow.json" --data-urlencode "group=ARCH_DEMO" \
  --data-urlencode "type=json" \
  --data-urlencode 'content=[{"resource":"inventory.reserve","grade":1,"count":100}]'
echo
