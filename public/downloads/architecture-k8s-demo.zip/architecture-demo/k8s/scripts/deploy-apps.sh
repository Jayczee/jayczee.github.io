#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
export KUBECONFIG="$PWD/target/kubeconfig"
kubectl --context kind-architecture-lab apply -f k8s/apps/config.yaml
for service in inventory payment orders gateway; do
  kubectl --context kind-architecture-lab apply -f "k8s/apps/$service.yaml"
  kubectl --context kind-architecture-lab -n order-lab rollout status "deployment/$service" --timeout=180s
done
kubectl --context kind-architecture-lab -n order-lab get pods,services
