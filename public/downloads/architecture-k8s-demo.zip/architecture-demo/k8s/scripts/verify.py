import json
import os
from pathlib import Path
import subprocess
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[2]
os.chdir(ROOT)
os.environ["KUBECONFIG"] = str(ROOT / "target/kubeconfig")
OUT = ROOT / "target/k8s-results.json"
CLIENT = urllib.request.build_opener(urllib.request.ProxyHandler({}))
RESULTS = {}


def kubectl(*args):
    return subprocess.check_output(["kubectl", "--context", "kind-architecture-lab", "-n", "order-lab", *args], text=True)


def pods(app):
    return [pod for pod in json.loads(kubectl("get", "pods", "-l", "app=" + app, "-o", "json"))["items"]
            if not pod["metadata"].get("deletionTimestamp")]


def eventually(check, description, seconds=120):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        try:
            if check():
                return
        except (OSError, urllib.error.URLError, subprocess.CalledProcessError):
            pass
        time.sleep(2)
    raise AssertionError(description)


def request(port, path, payload=None):
    data = None if payload is None else json.dumps(payload).encode()
    query = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=data,
                                   headers={"Content-Type": "application/json"})
    with CLIENT.open(query, timeout=10) as response:
        return json.load(response)


def hello():
    kubectl("apply", "-f", "k8s/hello/")
    kubectl("rollout", "status", "deployment/hello", "--timeout=120s")
    initial = {pod["metadata"]["uid"] for pod in pods("hello")}
    victim = pods("hello")[0]
    kubectl("delete", "pod", victim["metadata"]["name"], "--wait=true")
    eventually(lambda: len(pods("hello")) == 2 and all(
        any(condition["type"] == "Ready" and condition["status"] == "True"
            for condition in pod["status"].get("conditions", [])) for pod in pods("hello")), "replacement not ready")
    current = {pod["metadata"]["uid"] for pod in pods("hello")}
    assert len(initial & current) == 1
    RESULTS["podReplacement"] = {"oldUid": victim["metadata"]["uid"], "readyReplicas": 2}
    client = pods("hello")[0]["metadata"]["name"]
    replies = json.loads(kubectl("exec", client, "--", "python", "-c",
        "import json,urllib.request; print(json.dumps([json.load(urllib.request.urlopen('http://hello/')) for _ in range(30)]))"))
    assert len({row["pod"] for row in replies}) == 2, replies
    assert all(row["version"] == "v1" for row in replies)
    RESULTS["serviceDiscovery"] = {"hostnames": sorted({row["pod"] for row in replies}), "requests": 30}
    kubectl("exec", client, "--", "touch", "/tmp/not-ready")

    def ready_endpoint_count():
        slices = json.loads(kubectl("get", "endpointslices", "-l", "kubernetes.io/service-name=hello", "-o", "json"))["items"]
        return sum(endpoint.get("conditions", {}).get("ready", False)
                   for item in slices for endpoint in item.get("endpoints", []))

    try:
        eventually(lambda: ready_endpoint_count() == 1, "unready pod still selected")
        RESULTS["readiness"] = {"pods": len(pods("hello")), "readyServiceEndpoints": 1}
    finally:
        kubectl("exec", client, "--", "rm", "/tmp/not-ready")
    eventually(lambda: ready_endpoint_count() == 2, "readiness not restored")
    kubectl("set", "image", "deployment/hello", "hello=architecture-hello:v2")
    kubectl("rollout", "status", "deployment/hello", "--timeout=120s")
    assert all(pod["spec"]["containers"][0]["image"] == "architecture-hello:v2" for pod in pods("hello"))
    kubectl("set", "image", "deployment/hello", "hello=architecture-hello:missing")
    eventually(lambda: any(container.get("state", {}).get("waiting", {}).get("reason") in
               ("ErrImagePull", "ImagePullBackOff") for pod in pods("hello")
               for container in pod["status"].get("containerStatuses", [])), "missing image failure not observed", 90)
    assert ready_endpoint_count() == 2
    kubectl("rollout", "undo", "deployment/hello")
    kubectl("rollout", "status", "deployment/hello", "--timeout=120s")
    RESULTS["rollout"] = {"updatedTo": "v2", "missingImageKeptReadyEndpoints": 2, "rollbackTo": "v2"}


def business():
    processes = []
    logs = []
    try:
        for service, port in (("gateway", 28180), ("orders", 28183), ("inventory", 28184), ("payment", 28185)):
            log = open(ROOT / f"target/k8s-forward-{service}.log", "w")
            logs.append(log)
            processes.append(subprocess.Popen(["kubectl", "--context", "kind-architecture-lab", "-n", "order-lab",
                "port-forward", "service/" + service, f"{port}:8080", "--address=127.0.0.1"], stdout=log, stderr=log))
        eventually(lambda: request(28183, "/rpc-health").get("transport") == "dubbo", "Dubbo not ready")
        for port in (28183, 28184, 28185):
            request(port, "/reset", {})
        order = request(28180, "/api/orders", {"requestId": "k8s-review", "userId": 7, "sku": "SKU-A", "quantity": 2})
        assert order["status"] == "PENDING", order
        assert request(28183, "/drain", {})["status"] == "RESERVED"
        request(28180, "/api/pay", {"requestId": "k8s-review"})
        assert request(28183, "/drain", {})["status"] == "PAID"
        stock = request(28184, "/snapshot")["stock"][0]
        assert [stock["available"], stock["locked"], stock["sold"]] == [98, 0, 2]
        assert len(request(28185, "/snapshot")["payments"]) == 1
        previous = pods("orders")[0]["metadata"]["uid"]
        kubectl("rollout", "restart", "deployment/orders")
        kubectl("rollout", "status", "deployment/orders", "--timeout=180s")
        eventually(lambda: request(28180, "/api/orders/k8s-review")["status"] == "PAID", "order lost after restart")
        assert all(pod["metadata"]["uid"] != previous for pod in pods("orders") if not pod["metadata"].get("deletionTimestamp"))
        RESULTS["microservices"] = {"order": "PAID", "stock": [98, 0, 2], "payments": 1,
                                    "orderPodReplacedAndDataPreserved": True}
    finally:
        for process in processes:
            process.terminate()
        for process in processes:
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        for log in logs:
            log.close()


if __name__ == "__main__":
    OUT.unlink(missing_ok=True)
    hello()
    business()
    RESULTS["kubernetes"] = json.loads(kubectl("version", "-o", "json"))["serverVersion"]["gitVersion"]
    OUT.write_text(json.dumps(RESULTS, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(RESULTS, ensure_ascii=False, indent=2))
