#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
mkdir -p target
if kind get clusters | grep -qx architecture-lab; then
  echo "architecture-lab already exists; refusing to replace it."
  exit 1
fi
kind create cluster --name architecture-lab --config k8s/kind.yaml \
  --image kindest/node:v1.35.8@sha256:07b2536e30b803ed61d1677a79df6115f798ce64c80f9e22f6ed45afd09323c0 \
  --kubeconfig target/kubeconfig --wait 180s
kubectl --kubeconfig target/kubeconfig apply -f k8s/namespace.yaml
