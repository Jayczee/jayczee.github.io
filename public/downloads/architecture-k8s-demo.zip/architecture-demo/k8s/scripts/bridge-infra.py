import json
import subprocess


def container_ip(service):
    container = subprocess.check_output(
        ["docker", "compose", "-f", "k8s/infra/compose.yaml", "ps", "-q", service], text=True).strip()
    if not container:
        raise RuntimeError(service + " is not running")
    data = json.loads(subprocess.check_output(["docker", "inspect", container]))[0]
    return data["NetworkSettings"]["Networks"]["kind"]["IPAddress"]


items = []
for service, ports in (("mysql", [("mysql", 3306)]), ("nacos", [("http", 8848), ("grpc", 9848)])):
    items.append({
        "apiVersion": "v1", "kind": "Service",
        "metadata": {"name": service, "namespace": "order-lab"},
        "spec": {"ports": [{"name": name, "port": port, "targetPort": port} for name, port in ports]},
    })
    items.append({
        "apiVersion": "discovery.k8s.io/v1", "kind": "EndpointSlice",
        "metadata": {"name": service + "-external", "namespace": "order-lab",
                     "labels": {"kubernetes.io/service-name": service,
                                "endpointslice.kubernetes.io/managed-by": "architecture-lab"}},
        "addressType": "IPv4",
        "ports": [{"name": name, "protocol": "TCP", "port": port} for name, port in ports],
        "endpoints": [{"addresses": [container_ip(service)], "conditions": {"ready": True}}],
    })
print(json.dumps({"apiVersion": "v1", "kind": "List", "items": items}))
