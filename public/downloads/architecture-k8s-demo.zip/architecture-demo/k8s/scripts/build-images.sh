#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
mvn -B -ntp package
for entry in order-service:orders inventory-service:inventory payment-service:payment gateway-service:gateway; do
  module="${entry%:*}"
  service="${entry#*:}"
  docker build -t "architecture-$service:k8s-v1" "$module"
  kind load docker-image --name architecture-lab "architecture-$service:k8s-v1"
done
