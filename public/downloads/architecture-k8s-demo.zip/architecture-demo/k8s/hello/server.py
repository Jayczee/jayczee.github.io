import json
import os
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path not in ("/", "/health", "/ready"):
            self.send_error(404)
            return
        status = 503 if self.path == "/ready" and Path("/tmp/not-ready").exists() else 200
        body = json.dumps({
            "version": os.environ.get("APP_VERSION", "v1"),
            "pod": os.environ.get("HOSTNAME", "local"),
            "message": os.environ.get("MESSAGE", "hello from Docker"),
            "ready": status == 200,
        }).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


ThreadingHTTPServer(("0.0.0.0", 8080), Handler).serve_forever()
