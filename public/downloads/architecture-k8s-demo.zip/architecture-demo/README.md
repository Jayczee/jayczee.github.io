# architecture-demo

从订单、库存、支付单体迁移到 Spring Cloud Alibaba 的可运行教学工程。

Kubernetes 入门实验见 [k8s/README.md](k8s/README.md)：先用 hello 学习部署、Service、探针和回滚，再把四个业务应用迁入 kind。

- 单体：Spring MVC → Orders → 库存/支付模块 → 同一个 MySQL 库、本地事务。
- 微服务：Gateway → 订单 HTTP 服务 → Dubbo RPC → 库存/支付提供者 → 各自数据库。
- Nacos：HTTP 服务发现、Dubbo 注册中心和配置中心。
- Sentinel：库存 RPC 的预占入口限流，规则由 Nacos 推送。
- 本地 outbox + 请求幂等：处理超时、重复调用、支付已记账但库存未确认。
- 支付只模拟数据库记账，没有真实扣款。

## 版本

| 组件 | 固定版本 |
| --- | --- |
| Java | 17 |
| Spring Boot | 3.2.9 |
| Spring Cloud BOM | 2023.0.3 |
| Spring Cloud Alibaba BOM | 2023.0.3.2 |
| Dubbo | 3.3.0（显式指定，不由 Alibaba BOM 管理） |
| Nacos Server / Client | 2.4.2 |
| Sentinel | 1.8.8 |
| MySQL | 8.0.41 |

采用 Alibaba 2023.0.3.2 源码中配套的 Boot/Cloud 组合，固定版本便于复现；这组版本不代表最新发行版。升级应成组验证兼容性。

## 一键启动

需要 JDK 17+、Maven、Python 3、OpenSSL、Docker Engine 与 Compose v2。首次构建需要联网。

```bash
mvn -B -ntp package
bash scripts/up.sh
```

启动脚本生成仅本地保存的随机 MySQL 密码到 `secrets/mysql_password`（目录 700、文件 600）。Compose 将其挂载为 secret，Java 从 `ARCH_DB_PASSWORD_FILE` 读取。镜像只复制 jar，密码不在镜像、示例配置或 Git 中。独立 MySQL 容器与具名卷完全属于本项目；不依赖已有生产库。

`up.sh` 先等待 MySQL、Nacos 健康，发布 `ARCH_DEMO` 组下三个业务 YAML 和一份 Sentinel 规则，再启动应用。再次运行会将这些教学配置恢复默认值。Nacos 和 MySQL 数据保存在具名卷中。不要删除密码文件后继续复用原数据库卷。

所有宿主机端口绑定 `127.0.0.1`。Nacos 采用无鉴权单机模式，只用于私有 Docker 网络和本机实验访问。管理和故障注入入口未实现认证，不应直接暴露公网。

| 服务 | 宿主机入口 | 数据库/职责 |
| --- | --- | --- |
| gateway | 18180 | `/api/orders`、`/api/pay`、`/api/cancel` |
| monolith | 18182 | amdemo_monolith，完整单体 |
| orders | 18183 | amdemo_orders，订单和 outbox |
| inventory | 18184 | amdemo_inventory，库存与幂等预占 |
| payment | 18185 | amdemo_payment，支付幂等记录 |
| nacos | 18848 → 8848 | 控制台、配置与发现；19848 → 9848 为客户端 gRPC |

容器内部业务 HTTP 使用 8080，库存和支付的 Dubbo 使用 20880；容器分别有独立网络地址，因此端口可以相同。网关用 Nacos 的 `lb://orders` 找到 HTTP 实例，订单用 Dubbo 注册信息找到 RPC 提供者，不需要配置 `INVENTORY_URL`、`PAYMENT_URL`。

## 工程结构：每个应用一个独立 jar

```text
architecture-demo/
├── pom.xml                 父工程，packaging=pom
├── demo-contracts/         普通库：InventoryRpc、PaymentRpc
├── demo-support/           普通库：JDBC、事务、参数校验、异常处理、实验辅助
├── monolith-service/       完整单体，MonolithApplication
├── order-service/          订单，OrdersApplication
├── inventory-service/      库存，InventoryApplication
├── payment-service/        支付，PaymentApplication
└── gateway-service/        HTTP 网关，GatewayApplication
```

五个应用模块都有自己的 pom、启动类、application.yml、Dockerfile 和镜像。三个业务微服务依赖 contracts/support，但不互相依赖应用模块；订单包没有库存与支付实现，库存/支付 SQL 只在对应模块。单体保留自己的三块业务用于对照，不含 Cloud、Dubbo、Nacos、Sentinel 依赖。

父 pom 只聚合模块与管理版本；每个子模块自行声明依赖。Sentinel 只在库存模块引入。网关不依赖含 MVC/JDBC 的 support，以免与 WebFlux 混入同一应用。公共库不含业务建表或按角色切换的逻辑，各业务数据库类位于对应应用。

根目录一次 Maven package 会构建全部模块，产物包括五个 Spring Boot 可执行 jar、两个公共普通 jar。公共库被放入使用它的应用 jar 的 BOOT-INF/lib，不需要单独运行。不存在用 ARCH_ROLE 或 profile 选择业务服务的启动方式。

### 单独构建与部署库存

在完整环境已启动后：

```bash
mvn -B -ntp -pl inventory-service -am package
docker compose up -d --no-deps --build --force-recreate --wait inventory
curl -sS http://127.0.0.1:18183/rpc-health
```

`-pl` 选中库存模块，`-am` 连同所需公共模块一起构建；订单、支付、网关不会参与此次 Maven 构建。Compose 只替换库存容器；`--no-deps` 不连带启动依赖，`--force-recreate` 让未改代码时也能演示容器替换。依赖容器应当已经就绪。

Dockerfile 只复制 jar，因此改代码后必须先执行 Maven，再构建镜像。修改公共接口还要考虑与已部署调用方的兼容性；同仓库多模块支持独立部署，但不意味着接口可以任意不兼容地修改。

### 不使用 Docker 启动应用

先准备可访问的 MySQL、Nacos，并在 Nacos 中创建相同的教学配置。为业务进程设置 `ARCH_DB_HOST`、`ARCH_DB_PORT`、`ARCH_DB_USER`、`ARCH_DB_PASSWORD_FILE`，密码文件放本地 secrets/；三个微服务与网关还需设置 `NACOS_ADDR`。应用会在指定 MySQL 上创建 amdemo_ 前缀的示例库，使用专用实验实例。

下面每一行在一个独立终端启动一个应用：

```bash
java -jar monolith-service/target/monolith-service-1.0.0.jar
java -jar order-service/target/order-service-1.0.0.jar
DUBBO_PORT=20881 java -jar inventory-service/target/inventory-service-1.0.0.jar
DUBBO_PORT=20882 java -jar payment-service/target/payment-service-1.0.0.jar
java -jar gateway-service/target/gateway-service-1.0.0.jar
```

默认 HTTP 端口与表中一致，绑定127.0.0.1。多个 jar 在同一宿主机运行时，Dubbo 提供者必须设置不同端口；容器中各自有独立网络地址，所以可以都用20880。若 Nacos 使用 Compose 的宿主机映射，设置 `NACOS_ADDR=127.0.0.1:18848`，18848和19848都必须可达。默认 Compose 的 MySQL 不映射到宿主机，直接运行 jar 需要另外准备可连接的实验 MySQL；不要在 Compose 应用占用相同 HTTP 端口时同时运行本机 jar。

数据库固定为各应用专属的示例库，应用名也写在各自配置里。环境变量只调连接与端口，不决定本次启动哪个服务。

## 走完一笔订单

单体下单立即完成预占，返回 200 和 RESERVED：

```bash
curl -sS http://127.0.0.1:18182/orders \
  -H 'Content-Type: application/json' \
  -d '{"requestId":"mono-1","userId":7,"sku":"SKU-A","quantity":2}'
curl -sS http://127.0.0.1:18182/pay \
  -H 'Content-Type: application/json' -d '{"requestId":"mono-1"}'
```

微服务先受理为 202/PENDING。为观察每一步，Demo 没有自动消费 outbox，每次 `POST /drain` 处理一条事件：

```bash
curl -sS http://127.0.0.1:18180/api/orders \
  -H 'Content-Type: application/json' \
  -d '{"requestId":"micro-1","userId":7,"sku":"SKU-A","quantity":2}'
curl -sS -X POST http://127.0.0.1:18183/drain
curl -sS http://127.0.0.1:18180/api/pay \
  -H 'Content-Type: application/json' -d '{"requestId":"micro-1"}'
curl -sS -X POST http://127.0.0.1:18183/drain
curl -sS http://127.0.0.1:18180/api/orders/micro-1
curl -sS http://127.0.0.1:18184/snapshot
```

只做这一笔时，最终订单 PAID、库存可用/待处理/已售为 98/0/2、支付记录一条。再付一次不会重复记账。要取消，另建一单并完成预占，再 POST `/api/cancel` 和 `/drain`；已支付订单不能直接取消。

## 组件实操

### Nacos 服务发现

打开 `http://127.0.0.1:18848/nacos/`，查看 public 命名空间、ARCH_DEMO 分组。orders、inventory、payment、gateway 注册 HTTP 服务，Dubbo 在自己的注册/元数据机制下发布 RPC 服务。订单的 `GET /rpc-health` 会真实调用两个提供者的 `ping()`，比只看控制台显示“在线”更能确认调用链可用。

```bash
curl -sS http://127.0.0.1:18183/rpc-health
```

### Nacos 配置热更新

在控制台修改 `orders.yaml`（Group 为 `ARCH_DEMO`）：

```yaml
demo:
  message: hello-from-nacos
```

查询 `http://127.0.0.1:18183/config` 能看到变化。配置入口在 `order-service/src/main/resources/application.yml` 的 `spring.config.import`，Nacos 地址不能仅写进尚未能读取的远程配置中。public 的 namespace ID 留空；其他 namespace 必须填写实际 ID。

### Sentinel 动态限流

修改 `inventory-flow.json`：

```json
[{"resource":"inventory.reserve","grade":1,"count":0}]
```

0 会拒绝全部预占。创建订单并 drain 后，订单仍为 PENDING，库存不变；将 count 改回 100，等 `inventory /metrics` 中规则更新，再 drain 就能完成。限流返回可重试结果，不能被解释为库存不足。

实际资源入口是 `InventoryProvider` 中 `SphU.entry("inventory." + operation)`。仅装 Starter 不会自动产生这个自定义资源的规则。本例从 Nacos 持久化规则，不依赖 Sentinel Dashboard；尚未配置熔断规则，也没有将“限流成功”当成“熔断已验证”。

### 超时与重启

```bash
curl -sS http://127.0.0.1:18184/fault \
  -H 'Content-Type: application/json' -d '{"mode":"after"}'
```

下一次库存操作提交后延迟 1.5 秒返回，Dubbo consumer 只等 800ms，且 retries=0。订单 outbox 留下 PENDING，重启库存容器再 drain 时用同一 requestId 重放，库存不能再扣一次。

```bash
docker compose restart inventory
curl -sS http://127.0.0.1:18183/rpc-health
```

等待 RPC 恢复后再 drain。HTTP /health 成功只说明 HTTP 已就绪，注册传播和 Dubbo 连接还可能在建立中。

## 验证

在启动 Compose 的同一台机器、项目根目录执行：

```bash
python3 scripts/verify-packaging.py
python3 scripts/verify.py
python3 scripts/verify-cloud.py
python3 scripts/verify-deployment.py
```

这些是破坏性的教学数据实验：会重置本项目四个示例库内的表、停止/重启业务容器，并更改本项目 Nacos 配置。请勿并行执行或在这些库中保存要保留的业务数据。

- verify-packaging.py：检查五份可执行 jar 的启动类、业务代码隔离和公共普通库，确认单体不含 Cloud 依赖。
- verify-deployment.py：只重建库存并确认订单、支付容器 ID 不变；暂时停止 Nacos，重新创建单体容器并真实下单付款，最后恢复 Nacos。
- verify.py：单体回滚、幂等、库存竞争、真实 Dubbo 超时、订单/库存/支付重启恢复、取消、服务停止、有限重试与对账。库存 HTTP 辅助接口用于单独演示错误扣减与数据库并发。
- verify-cloud.py：Nacos 注册发现/热更新、网关路由、真实 Dubbo 支付和业务拒绝、Sentinel 动态规则、RPC 超时后 provider 重启及恢复。
- 各脚本均仅在自己的全部断言通过时写结果，输出在 `target/experiments/`；Maven 构建不能替代集成验证。
- 完成后容器继续运行，cloud 脚本保留 `review-paid` 已支付订单供检查。

### 管理入口

`/health`、`/snapshot`、`/metrics`、`/config` 为 GET；`/reset`、`/fault`、`/drain` 为 POST。库存的 `/reserve`、`/confirm`、`/release`、`/unsafe-reserve` 仅用于对照实验，订单业务实际走 Dubbo，网关不转发这些入口。

```bash
docker compose ps
docker compose logs --tail=100 orders inventory payment
docker compose down
```

down 保留数据卷。恢复用 up.sh，会重新发布默认教学配置。

## 尚未实现的生产能力

Seata、RocketMQ、自动 outbox worker、租约/退避、鉴权、独立数据库账号、熔断规则、多实例压测和告警不在本轮实现中。outbox 处理在订单事务持锁期间等待 RPC，适合观察恢复过程，实际部署应改为短事务领取/确认、租约、退避与人工处置。

五次失败后事件 FAILED，订单保持中间态，不能伪装成功；需要人工对账决定重放或补偿。支付只是数据库记账，真实第三方支付还需要回调验签、渠道查询、退款与对账。Seata AT 无法自动撤销真实外部支付。

所有应用共用 Demo 专用 MySQL 实例的测试账号，故障隔离只到应用进程；同宿主机和同数据库实例仍是共享故障点。
