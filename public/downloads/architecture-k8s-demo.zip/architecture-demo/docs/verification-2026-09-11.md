# 2026-09-11 独立 jar 微服务迁移验证

运行位置：授权服务器的独立 Docker Compose 项目 architecture-demo。七个容器分别为 MySQL、Nacos、monolith、orders、inventory、payment、gateway。未修改原有 MySQL 容器及其他业务服务。原先两种单体对照收敛为一个完整 monolith 应用，旧容器已由 Compose 移除，数据卷保留。

实际运行时为 Temurin Java 17.0.20；Spring Boot 3.2.9、Cloud 2023.0.3、Alibaba 2023.0.3.2、Dubbo 3.3.0、Nacos Server/Client 2.4.2、Sentinel 1.8.8、MySQL Server 8.0.41。服务间订单业务调用已使用 Dubbo，不再使用 JDK HttpClient。

## 执行结果

- `mvn -B -ntp clean package`：全部模块通过。
- `mvn -B -ntp -pl inventory-service -am package`：只构建父工程、contracts、support、inventory，通过。
- `python3 scripts/verify-packaging.py`：本地与服务器均通过；核验五份可执行 jar 和两个公共普通 jar。
- `python3 scripts/verify.py`：全部断言通过。
- `python3 scripts/verify-cloud.py`：全部断言通过。
- `python3 scripts/verify-deployment.py`：独立库存部署、Nacos 停止期间单体重新启动及真实付款通过。
- 七个容器全部 running / healthy。

Maven 当前没有 JUnit 用例。业务和部署验证来自在 Docker 环境中执行的 Python 集成脚本。原始结果在 target/experiments/ 下：packaging-results.json、results.json、cloud-results.json、deployment-results.json；运行日志在服务器 target/verify.log、target/verify-cloud.log、target/verify-deployment.log。结果文件已拷回本地工程。

## 独立构建与部署

| 应用 | 产物 | 启动类（共同包名前缀省略） |
| --- | --- | --- |
| 单体 | monolith-service/target/monolith-service-1.0.0.jar | monolith.MonolithApplication |
| 订单 | order-service/target/order-service-1.0.0.jar | orders.OrdersApplication |
| 库存 | inventory-service/target/inventory-service-1.0.0.jar | inventory.InventoryApplication |
| 支付 | payment-service/target/payment-service-1.0.0.jar | payment.PaymentApplication |
| 网关 | gateway-service/target/gateway-service-1.0.0.jar | gateway.GatewayApplication |

打包检查递归检查应用 jar 与嵌套依赖 jar：各应用均未包含其他服务包中的业务类；订单不含 InventoryModule/PaymentModule；单体不含 Spring Cloud、Nacos、Dubbo、Sentinel 类。demo-contracts 普通 jar 只有两个 RPC 接口，demo-support 普通 jar 只有 support 包的辅助类。

执行 `docker compose up -d --no-deps --build --force-recreate --wait inventory` 前后：

- 库存容器 ID 从 b2f7464e6b0f 变为 806434b536a7。
- 订单容器 ID 保持 05a443c8e651，支付保持 876a7032598b。
- 库存 snapshot 完全一致，订单 `/rpc-health` 再次真实调用库存与支付并返回正常。

随后停止 Nacos，重新创建 monolith 容器，健康检查正常。清空单体教学数据后创建 monolith-no-nacos 并付款，结果 PAID、库存98/0/2、支付一条。最后恢复 Nacos，微服务 RPC 恢复，所有容器健康。

## 真实业务与故障场景

| 场景 | 实测 |
| --- | --- |
| 完整单体，库存写入后故障 | 订单 0，库存 100/0/0 |
| 无幂等 HTTP 辅助接口，超时后重试 | 98/2/0 → 96/4/0 |
| 库存重启，再用 8 工作线程重放 16 次 | 库存仍为 98/2/0 |
| 库存 HTTP 接口 20 笔并发各抢 6 件 | 16 成功、4 拒绝，库存 4/96/0 |
| 先释放、后预占 | 迟到的预占返回 409 |
| 订单经 Dubbo 预占后响应超时，再重启订单和库存 | PENDING → RESERVED，库存 98/2/0，userId=7 |
| 支付成功，库存确认 RPC 失败，再重启支付 | PAY_PENDING → PAID，支付仍 1 条，库存 98/0/2 |
| 停止库存容器 | 订单仍可受理为 202，历史 PAID 订单可读 |
| 完整流程对账 | 3 笔订单、1 条支付、库存 96/2/2、问题 [] |
| 连续五次通信失败 | 事件 FAILED、订单 PENDING；恢复服务后不自动重放 |
| Nacos HTTP 服务发现 | ARCH_DEMO 下有 orders、inventory、payment、gateway |
| Nacos orders.yaml 热更新 | 不重启订单应用，/config 变为 live-update-v2 |
| Gateway → orders → Dubbo inventory/payment | 订单 PAID，库存 98/0/2，支付一条 |
| 经 Dubbo 处理明确库存不足 | 订单 REJECTED |
| Sentinel count=0，再改回 100 | 拦截时库存不变；规则更新后完成预占 |
| Dubbo 800ms 超时后重启库存并重放 | 消息 attempts=1；库存维持 94/4/2，没有重复预占 |
| 20 单经 Gateway 并发受理，再逐条 Dubbo 处理 | 16 成功、4 拒绝，库存 4/96/0 |
| 网关请求 /api/reset | 404，未转发管理入口 |

库存数字依次为可用/待处理/已售；不同实验之间会重置数据，不能把表内数字累加。HTTP 辅助接口的数据库并发实验与 Gateway/Dubbo 业务链路验证分别记录，后者没有证明多实例并发吞吐。

最终保留 review-paid：userId=7、SKU-A、数量2、amountFen=2000、PAID。配套库存 98/0/2，支付记录一条，两条 outbox 均 DONE。

## 实际遇到的问题

应用依赖若放在父 pom 的 dependencies 中，子应用会一起继承，单体可能也加载 Dubbo 自动配置和远程引用。本版父 pom 仅保留版本管理，三个微服务各自引入 Dubbo/Nacos 并在自己的启动类上开启扫描。单体自己的 classpath 不含这些组件，已通过停掉 Nacos 后重新创建单体容器的验证。

Dockerfile 只复制各模块 target 中已经构建好的 jar。独立发布时先执行 Maven，再执行 Docker build/up；只修改源码和重建镜像不会重新编译 Java。每个 Docker 构建目录只允许对应模块的 jar 进入上下文。

服务器 Docker 镜像下载较慢，最终从官方 Registry 获取 linux/amd64 镜像，校验各层 SHA-256 后导入服务器。未修改全局 Docker 配置或重启 Docker daemon。

## 边界与凭证

- 七个容器同宿主机，三个微服务共用 Demo 专用 MySQL 实例中的不同库，不代表数据库硬件故障隔离。
- RPC 超时由提供者提交后延迟 1500ms、调用方 800ms 超时制造；HTTP 对照实验的调用方期限为 500ms。
- 重启使用 docker compose stop/up 或 restart，没有模拟宿主机断电和数据库提交中断。
- Sentinel 仅验证 Nacos 下发的限流规则；未部署 Dashboard、未配置熔断，也未接入 Seata、RocketMQ。
- outbox 手动 drain，最多两个处理者；本轮服务停止实验记录最大同时处理者为 1，没有把它当成高并发隔离证明。
- 支付为数据库记账，未接真实支付渠道；无自动退款、告警、失败事件自动重放或生产级 worker。
- 数据库使用新生成的随机密码，通过 Compose secret 挂载；secrets/ 被 Git 忽略，Docker 构建上下文只允许 jar。未保存用户的 SSH/MySQL 凭证。
- HTTP 与 Nacos 的宿主机映射仅监听 127.0.0.1，审阅使用 SSH 端口转发。
