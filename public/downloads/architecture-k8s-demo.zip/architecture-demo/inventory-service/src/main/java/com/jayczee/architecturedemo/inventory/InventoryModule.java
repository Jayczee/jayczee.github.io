package com.jayczee.architecturedemo.inventory;

import com.jayczee.architecturedemo.support.Database;
import com.jayczee.architecturedemo.support.BusinessConflict;

import java.util.Map;

public final class InventoryModule {
    private final Database database;

    InventoryModule(Database database) { this.database = database; }

    public Map<String, Object> apply(String operation, String requestId, String sku, int quantity) {
        return database.transaction(() -> {
            database.jdbc.update("""
                    insert into reservation values (?, ?, ?, 'NEW')
                    on duplicate key update request_id=request_id
                    """, requestId, sku, quantity);
            Map<String, Object> row = database.jdbc.queryForMap(
                    "select * from reservation where request_id=? for update", requestId);
            if (!sku.equals(row.get("sku")) || quantity != ((Number) row.get("quantity")).intValue()) {
                throw new BusinessConflict("request payload changed");
            }
            String state = (String) row.get("state");
            String next;
            switch (operation) {
                case "reserve" -> {
                    if (state.equals("HELD") || state.equals("CONFIRMED")) return row;
                    if (!state.equals("NEW")) throw new BusinessConflict("reservation already released");
                    int changed = database.jdbc.update("""
                            update stock set available=available-?, locked=locked+?
                            where sku=? and available>=?
                            """, quantity, quantity, sku, quantity);
                    if (changed == 0) throw new BusinessConflict("insufficient stock");
                    next = "HELD";
                }
                case "confirm" -> {
                    if (state.equals("CONFIRMED")) return row;
                    if (!state.equals("HELD")) throw new BusinessConflict("reservation not held");
                    database.jdbc.update("update stock set locked=locked-?, sold=sold+? where sku=?",
                            quantity, quantity, sku);
                    next = "CONFIRMED";
                }
                case "release" -> {
                    if (state.equals("RELEASED")) return row;
                    if (state.equals("CONFIRMED")) throw new BusinessConflict("confirmed reservation needs refund flow");
                    if (state.equals("HELD")) {
                        database.jdbc.update("update stock set locked=locked-?, available=available+? where sku=?",
                                quantity, quantity, sku);
                    }
                    next = "RELEASED";
                }
                default -> throw new IllegalArgumentException("unknown inventory operation");
            }
            database.jdbc.update("update reservation set state=? where request_id=?", next, requestId);
            return database.jdbc.queryForMap("select * from reservation where request_id=?", requestId);
        });
    }

}
