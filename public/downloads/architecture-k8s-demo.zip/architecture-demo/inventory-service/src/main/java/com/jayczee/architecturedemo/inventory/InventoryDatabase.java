package com.jayczee.architecturedemo.inventory;

import com.jayczee.architecturedemo.support.Database;
import java.util.LinkedHashMap;
import java.util.Map;

public final class InventoryDatabase extends Database {
    public InventoryDatabase() throws Exception {
        super("amdemo_inventory");
        jdbc.execute("""
                create table if not exists stock (
                    sku varchar(40) primary key, available int not null,
                    locked int not null, sold int not null
                ) engine=InnoDB
                """);
        jdbc.execute("""
                create table if not exists reservation (
                    request_id varchar(80) primary key, sku varchar(40) not null,
                    quantity int not null, state varchar(12) not null
                ) engine=InnoDB
                """);
        jdbc.update("insert ignore into stock values ('SKU-A', 100, 0, 0)");
    }

    @Override
    public void reset() {
        transaction(() -> {
            jdbc.update("delete from reservation");
            jdbc.update("update stock set available=100, locked=0, sold=0 where sku='SKU-A'");
            return null;
        });
    }

    @Override
    public Map<String, Object> snapshot() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("stock", jdbc.queryForList("select * from stock order by sku"));
        result.put("reservations", jdbc.queryForList("select * from reservation order by request_id"));
        return result;
    }
}
