package com.jayczee.architecturedemo.inventory;

import com.jayczee.architecturedemo.support.ApiErrors;
import com.jayczee.architecturedemo.support.Faults;
import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

@EnableDubbo
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
@Import({ApiErrors.class, Faults.class})
public class InventoryApplication {
    public static void main(String[] args) { SpringApplication.run(InventoryApplication.class, args); }

    @Bean(destroyMethod = "close")
    InventoryDatabase database() throws Exception { return new InventoryDatabase(); }

    @Bean
    InventoryModule inventory(InventoryDatabase database) { return new InventoryModule(database); }
}
