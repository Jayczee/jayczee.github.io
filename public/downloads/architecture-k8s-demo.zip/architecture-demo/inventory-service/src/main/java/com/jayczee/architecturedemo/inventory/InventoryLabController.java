package com.jayczee.architecturedemo.inventory;

import java.util.Map;
import com.jayczee.architecturedemo.support.BusinessConflict;
import com.jayczee.architecturedemo.support.Faults;
import com.jayczee.architecturedemo.support.Input;
import org.springframework.web.bind.annotation.*;

@RestController
public class InventoryLabController {
    private final InventoryDatabase database;
    private final InventoryModule inventory;
    private final Faults faults;

    public InventoryLabController(InventoryDatabase database, InventoryModule inventory, Faults faults) {
        this.database = database;
        this.inventory = inventory;
        this.faults = faults;
    }

    @PostMapping({"/reserve", "/confirm", "/release", "/unsafe-reserve"})
    public Object inventoryLab(@RequestBody Map<String, Object> body, jakarta.servlet.http.HttpServletRequest request) {
        String requestId = Input.text(body, "requestId");
        String sku = Input.text(body, "sku");
        int quantity = Input.quantity(body);
        if (sku.length() > 40) throw new IllegalArgumentException("invalid sku");
        String mode = faults.take();
        String action = request.getRequestURI().substring(1);
        Object result;
        if (action.equals("unsafe-reserve")) {
            int changed = database.jdbc.update("""
                    update stock set available=available-?, locked=locked+?
                    where sku=? and available>=?
                    """, quantity, quantity, sku, quantity);
            if (changed == 0) throw new BusinessConflict("insufficient stock");
            result = Map.of("reserved", quantity);
        } else {
            result = inventory.apply(action, requestId, sku, quantity);
        }
        faults.after(mode);
        return result;
    }

}
