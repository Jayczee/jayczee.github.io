package com.jayczee.architecturedemo.inventory;

import com.jayczee.architecturedemo.support.AdminEndpoints;
import com.jayczee.architecturedemo.support.Faults;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRuleManager;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController extends AdminEndpoints {
    public AdminController(InventoryDatabase database, Faults faults, Environment environment) {
        super("inventory", database, faults, environment);
    }

    @Override
    @GetMapping("/metrics")
    public Map<String, Object> metrics() {
        Map<String, Object> result = super.metrics();
        result.put("sentinelRules", FlowRuleManager.getRules());
        return result;
    }
}
