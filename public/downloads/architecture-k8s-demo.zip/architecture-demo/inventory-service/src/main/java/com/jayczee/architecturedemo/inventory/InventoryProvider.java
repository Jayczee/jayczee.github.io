package com.jayczee.architecturedemo.inventory;

import com.jayczee.architecturedemo.support.BusinessConflict;
import com.jayczee.architecturedemo.support.Faults;
import com.jayczee.architecturedemo.support.Input;

import com.alibaba.csp.sentinel.Entry;
import com.alibaba.csp.sentinel.SphU;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import com.jayczee.architecturedemo.api.InventoryRpc;
import java.util.List;
import org.apache.dubbo.config.annotation.DubboService;

@DubboService(version = "1.0.0", group = "architecture-demo")
public class InventoryProvider implements InventoryRpc {
    private final InventoryModule inventory;
    private final Faults faults;

    public InventoryProvider(InventoryModule inventory, Faults faults) {
        this.inventory = inventory;
        this.faults = faults;
    }

    @Override
    public String ping() { return "inventory"; }

    @Override
    public String apply(String operation, String requestId, String sku, int quantity) {
        if (!List.of("reserve", "confirm", "release").contains(operation)) throw new IllegalArgumentException("invalid operation");
        Input.validateId(requestId);
        Input.validateId(sku);
        if (sku.length() > 40 || quantity < 1 || quantity > 10000) throw new IllegalArgumentException("invalid inventory input");
        try (Entry entry = SphU.entry("inventory." + operation)) {
            String mode = faults.take();
            inventory.apply(operation, requestId, sku, quantity);
            System.out.printf("request=%s role=inventory transport=dubbo action=%s committed=true%n", requestId, operation);
            faults.after(mode);
            return "OK";
        } catch (BusinessConflict conflict) {
            return "CONFLICT:" + conflict.getMessage();
        } catch (BlockException blocked) {
            return "RETRY:sentinel";
        }
    }
}
