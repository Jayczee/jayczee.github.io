package com.jayczee.architecturedemo.monolith;

import com.jayczee.architecturedemo.support.ApiErrors;
import com.jayczee.architecturedemo.support.Faults;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
@Import({ApiErrors.class, Faults.class})
public class MonolithApplication {
    public static void main(String[] args) { SpringApplication.run(MonolithApplication.class, args); }

    @Bean(destroyMethod = "close")
    MonolithDatabase database() throws Exception { return new MonolithDatabase(); }

    @Bean
    Orders orders(MonolithDatabase database) { return new Orders(database); }
}
