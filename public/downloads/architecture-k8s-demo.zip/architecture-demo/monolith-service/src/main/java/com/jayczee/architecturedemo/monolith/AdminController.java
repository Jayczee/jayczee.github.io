package com.jayczee.architecturedemo.monolith;

import com.jayczee.architecturedemo.support.AdminEndpoints;
import com.jayczee.architecturedemo.support.Faults;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController extends AdminEndpoints {
    public AdminController(MonolithDatabase database, Faults faults, Environment environment) {
        super("monolith", database, faults, environment);
    }
}
