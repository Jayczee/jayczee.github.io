package com.jayczee.architecturedemo.monolith;

import com.jayczee.architecturedemo.support.Database;
import com.jayczee.architecturedemo.support.BusinessConflict;

import java.util.Map;

public final class PaymentModule {
    private final Database database;

    PaymentModule(Database database) { this.database = database; }

    public Map<String, Object> charge(String requestId, long amountFen) {
        return database.transaction(() -> {
            database.jdbc.update("""
                    insert into payment values (?, ?)
                    on duplicate key update request_id=request_id
                    """, requestId, amountFen);
            Map<String, Object> row = database.jdbc.queryForMap(
                    "select * from payment where request_id=? for update", requestId);
            if (((Number) row.get("amount_fen")).longValue() != amountFen) {
                throw new BusinessConflict("payment payload changed");
            }
            return row;
        });
    }
}
