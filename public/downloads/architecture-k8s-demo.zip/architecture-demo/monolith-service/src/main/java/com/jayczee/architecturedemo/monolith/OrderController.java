package com.jayczee.architecturedemo.monolith;

import java.util.Map;
import com.jayczee.architecturedemo.support.Input;
import com.jayczee.architecturedemo.support.Faults;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class OrderController {
    private final Orders orders;
    private final Faults faults;

    public OrderController(Orders orders, Faults faults) {
        this.orders = orders;
        this.faults = faults;
    }

    @GetMapping("/orders/{requestId}")
    public Object find(@PathVariable String requestId) { return orders.find(requestId); }

    @PostMapping("/orders")
    public ResponseEntity<?> place(@RequestBody Map<String, Object> body) {
        String requestId = Input.text(body, "requestId");
        String sku = Input.text(body, "sku");
        int quantity = Input.quantity(body);
        long userId = Input.number(body, "userId");
        if (userId < 1 || sku.length() > 40) throw new IllegalArgumentException("invalid user or sku");
        Object result = orders.place(requestId, userId, sku, quantity, faults.take().equals("rollback"));
        return ResponseEntity.status(200).body(result);
    }

    @PostMapping({"/pay", "/cancel"})
    public ResponseEntity<?> transition(@RequestBody Map<String, Object> body, jakarta.servlet.http.HttpServletRequest request) {
        Object result = orders.transition(Input.text(body, "requestId"), request.getRequestURI().equals("/pay") ? "PAY" : "CANCEL");
        return ResponseEntity.status(200).body(result);
    }
}
