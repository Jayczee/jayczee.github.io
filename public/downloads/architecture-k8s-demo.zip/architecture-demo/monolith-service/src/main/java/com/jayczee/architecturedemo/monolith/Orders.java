package com.jayczee.architecturedemo.monolith;

import com.jayczee.architecturedemo.support.BusinessConflict;

import java.util.Map;

public final class Orders {
    private final MonolithDatabase database;
    private final InventoryModule inventory;
    private final PaymentModule payment;
    Orders(MonolithDatabase database) {
        this.database = database;
        inventory = new InventoryModule(database);
        payment = new PaymentModule(database);
    }

    public Map<String, Object> place(String requestId, long userId, String sku, int quantity) {
        return place(requestId, userId, sku, quantity, false);
    }

    public Map<String, Object> place(String requestId, long userId, String sku, int quantity, boolean failAfterStock) {
        return database.transaction(() -> {
            database.jdbc.update("""
                    insert into orders values (?, ?, ?, ?, 'NEW', ?)
                    on duplicate key update request_id=request_id
                    """, requestId, userId, sku, quantity, quantity * 1000L);
            Map<String, Object> row = locked(requestId);
            if (!sku.equals(row.get("sku")) || userId != ((Number) row.get("user_id")).longValue()
                    || quantity != ((Number) row.get("quantity")).intValue()) {
                throw new BusinessConflict("order request payload changed");
            }
            if (!row.get("status").equals("NEW")) return row;
            inventory.apply("reserve", requestId, sku, quantity);
            if (failAfterStock) throw new IllegalStateException("injected failure after stock write");
            status(requestId, "RESERVED");
            return find(requestId);
        });
    }

    public Map<String, Object> transition(String requestId, String kind) {
        return database.transaction(() -> {
            Map<String, Object> row = locked(requestId);
            String current = (String) row.get("status");
            String finished = kind.equals("PAY") ? "PAID" : "CANCELLED";
            String pending = kind + "_PENDING";
            if (current.equals(finished) || current.equals(pending)) return row;
            if (!current.equals("RESERVED")) throw new BusinessConflict("order is " + current);
            if (kind.equals("PAY")) {
                payment.charge(requestId, ((Number) row.get("amount_fen")).longValue());
                inventory.apply("confirm", requestId, (String) row.get("sku"), ((Number) row.get("quantity")).intValue());
            } else {
                inventory.apply("release", requestId, (String) row.get("sku"), ((Number) row.get("quantity")).intValue());
            }
            status(requestId, finished);
            return find(requestId);
        });
    }

    public Map<String, Object> find(String requestId) {
        return database.jdbc.queryForMap("select * from orders where request_id=?", requestId);
    }

    private Map<String, Object> locked(String requestId) {
        return database.jdbc.queryForMap("select * from orders where request_id=? for update", requestId);
    }

    private void status(String requestId, String state) {
        database.jdbc.update("update orders set status=? where request_id=?", state, requestId);
    }
}
