package com.jayczee.architecturedemo.support;

import java.util.Map;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.web.servlet.resource.NoResourceFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ApiErrors {
    @ExceptionHandler(BusinessConflict.class)
    public ResponseEntity<?> conflict(BusinessConflict failure) {
        return ResponseEntity.status(409).body(Map.of("error", failure.getMessage()));
    }

    @ExceptionHandler({EmptyResultDataAccessException.class, NoResourceFoundException.class})
    public ResponseEntity<?> missing() { return ResponseEntity.status(404).body(Map.of("error", "not found")); }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<?> badInput(IllegalArgumentException failure) {
        return ResponseEntity.badRequest().body(Map.of("error", failure.getMessage()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> unavailable(Exception failure) {
        System.out.printf("failure=%s%n", failure.getClass().getSimpleName());
        return ResponseEntity.status(503).body(Map.of("error", "operation unavailable"));
    }
}
