package com.jayczee.architecturedemo.support;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.sql.DriverManager;
import java.util.Map;
import java.util.function.Supplier;

public abstract class Database implements AutoCloseable {
    private final HikariDataSource pool;
    public final JdbcTemplate jdbc;
    private final TransactionTemplate transactions;

    protected Database(String schema) throws Exception {
        if (!schema.matches("amdemo_[a-z]+")) throw new IllegalArgumentException("invalid demo schema");
        String host = env("ARCH_DB_HOST", "127.0.0.1");
        String port = env("ARCH_DB_PORT", "3306");
        String username = env("ARCH_DB_USER", "root");
        String passwordFile = System.getenv("ARCH_DB_PASSWORD_FILE");
        String password = passwordFile == null ? System.getenv("ARCH_DB_PASSWORD")
                : java.nio.file.Files.readString(java.nio.file.Path.of(passwordFile)).strip();
        if (password == null || password.isBlank()) throw new IllegalArgumentException("ARCH_DB_PASSWORD required");
        String base = "jdbc:mysql://" + host + ":" + port + "/";
        String options = "?connectionTimeZone=UTC&forceConnectionTimeZoneToSession=true&allowPublicKeyRetrieval=true&useSSL=false";
        try (var connection = DriverManager.getConnection(base + options, username, password);
             var statement = connection.createStatement()) {
            statement.execute("create database if not exists " + schema + " character set utf8mb4");
        }
        HikariConfig configuration = new HikariConfig();
        configuration.setJdbcUrl(base + schema + options);
        configuration.setUsername(username);
        configuration.setPassword(password);
        configuration.setMaximumPoolSize(4);
        configuration.setMinimumIdle(1);
        configuration.setConnectionTimeout(1500);
        pool = new HikariDataSource(configuration);
        jdbc = new JdbcTemplate(pool);
        transactions = new TransactionTemplate(new DataSourceTransactionManager(pool));
    }

    public <Result> Result transaction(Supplier<Result> work) {
        return transactions.execute(status -> work.get());
    }

    public abstract void reset();

    public abstract Map<String, Object> snapshot();

    public Map<String, Object> metrics() {
        return Map.of("poolActive", pool.getHikariPoolMXBean().getActiveConnections(),
                "poolTotal", pool.getHikariPoolMXBean().getTotalConnections(),
                "heapUsedBytes", Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory());
    }

    public static String env(String name, String fallback) {
        return System.getenv().getOrDefault(name, fallback);
    }

    @Override
    public void close() { pool.close(); }
}
