package com.jayczee.architecturedemo.support;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import org.springframework.stereotype.Component;

@Component
public class Faults {
    private final AtomicReference<String> mode = new AtomicReference<>("none");

    public void set(String value) {
        if (!List.of("none", "before", "after", "rollback").contains(value)) {
            throw new IllegalArgumentException("invalid fault");
        }
        mode.set(value);
    }

    public String take() {
        String value = mode.getAndSet("none");
        if (value.equals("before")) throw new IllegalStateException("injected unavailable before commit");
        return value;
    }

    public void after(String value) {
        if (value.equals("after")) {
            try { Thread.sleep(1500); }
            catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException("response interrupted");
            }
        }
    }
}
