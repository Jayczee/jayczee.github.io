package com.jayczee.architecturedemo.support;

import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

public abstract class AdminEndpoints {
    protected final Database database;
    private final String service;
    private final Faults faults;
    private final Environment environment;

    protected AdminEndpoints(String service, Database database, Faults faults, Environment environment) {
        this.service = service;
        this.database = database;
        this.faults = faults;
        this.environment = environment;
    }

    @GetMapping("/health")
    public Object health() { return Map.of("role", service, "ready", true); }

    @GetMapping("/config")
    public Object config() { return Map.of("message", environment.getProperty("demo.message", "local-default")); }

    @GetMapping("/metrics")
    public Map<String, Object> metrics() { return new LinkedHashMap<>(database.metrics()); }

    @GetMapping("/snapshot")
    public Object snapshot() {
        Map<String, Object> result = new LinkedHashMap<>(database.snapshot());
        result.put("role", service);
        return result;
    }

    @PostMapping("/reset")
    public Object reset() {
        database.reset();
        faults.set("none");
        return Map.of("reset", service);
    }

    @PostMapping("/fault")
    public Object fault(@RequestBody Map<String, Object> body) {
        String mode = String.valueOf(body.getOrDefault("mode", "none"));
        faults.set(mode);
        return Map.of("mode", mode);
    }
}
