package com.jayczee.architecturedemo.support;

import java.util.Map;

public final class Input {
    private Input() {}

    public static void validateId(String value) {
        if (value == null || !value.matches("[A-Za-z0-9_-]{1,80}")) throw new IllegalArgumentException("invalid id");
    }

    public static String text(Map<String, Object> body, String key) {
        if (!(body.get(key) instanceof String value)) throw new IllegalArgumentException("invalid " + key);
        validateId(value);
        return value;
    }

    public static long number(Map<String, Object> body, String key) {
        if (!(body.get(key) instanceof Number value) || value.doubleValue() != value.longValue()) {
            throw new IllegalArgumentException("integer required for " + key);
        }
        return value.longValue();
    }

    public static int quantity(Map<String, Object> body) {
        long quantity = number(body, "quantity");
        if (quantity < 1 || quantity > 10000) throw new IllegalArgumentException("invalid quantity");
        return (int) quantity;
    }
}
