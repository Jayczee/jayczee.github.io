package com.jayczee.architecturedemo.support;

public class BusinessConflict extends RuntimeException {
    public BusinessConflict(String message) { super(message); }
}
