package com.jayczee.architecturedemo.api;

public interface PaymentRpc {
    String ping();
    String charge(String requestId, long amountFen);
}
