package com.jayczee.architecturedemo.api;

public interface InventoryRpc {
    String ping();
    String apply(String operation, String requestId, String sku, int quantity);
}
