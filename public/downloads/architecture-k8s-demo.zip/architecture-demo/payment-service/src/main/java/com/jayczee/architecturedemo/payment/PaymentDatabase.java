package com.jayczee.architecturedemo.payment;

import com.jayczee.architecturedemo.support.Database;
import java.util.LinkedHashMap;
import java.util.Map;

public final class PaymentDatabase extends Database {
    public PaymentDatabase() throws Exception {
        super("amdemo_payment");
        jdbc.execute("""
                create table if not exists payment (
                    request_id varchar(80) primary key, amount_fen bigint not null
                ) engine=InnoDB
                """);
    }

    @Override
    public void reset() {
        transaction(() -> {
            jdbc.update("delete from payment");
            return null;
        });
    }

    @Override
    public Map<String, Object> snapshot() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("payments", jdbc.queryForList("select * from payment order by request_id"));
        return result;
    }
}
