package com.jayczee.architecturedemo.payment;

import com.jayczee.architecturedemo.support.ApiErrors;
import com.jayczee.architecturedemo.support.Faults;
import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

@EnableDubbo
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
@Import({ApiErrors.class, Faults.class})
public class PaymentApplication {
    public static void main(String[] args) { SpringApplication.run(PaymentApplication.class, args); }

    @Bean(destroyMethod = "close")
    PaymentDatabase database() throws Exception { return new PaymentDatabase(); }

    @Bean
    PaymentModule payment(PaymentDatabase database) { return new PaymentModule(database); }
}
