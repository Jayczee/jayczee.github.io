package com.jayczee.architecturedemo.payment;

import com.jayczee.architecturedemo.support.AdminEndpoints;
import com.jayczee.architecturedemo.support.Faults;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController extends AdminEndpoints {
    public AdminController(PaymentDatabase database, Faults faults, Environment environment) {
        super("payment", database, faults, environment);
    }
}
