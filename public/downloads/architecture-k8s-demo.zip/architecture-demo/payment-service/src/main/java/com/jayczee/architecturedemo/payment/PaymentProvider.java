package com.jayczee.architecturedemo.payment;

import com.jayczee.architecturedemo.support.BusinessConflict;
import com.jayczee.architecturedemo.support.Faults;
import com.jayczee.architecturedemo.support.Input;

import com.jayczee.architecturedemo.api.PaymentRpc;
import org.apache.dubbo.config.annotation.DubboService;

@DubboService(version = "1.0.0", group = "architecture-demo")
public class PaymentProvider implements PaymentRpc {
    private final PaymentModule payment;
    private final Faults faults;

    public PaymentProvider(PaymentModule payment, Faults faults) {
        this.payment = payment;
        this.faults = faults;
    }

    @Override
    public String ping() { return "payment"; }

    @Override
    public String charge(String requestId, long amountFen) {
        Input.validateId(requestId);
        if (amountFen < 1) throw new IllegalArgumentException("invalid payment amount");
        String mode = faults.take();
        try { payment.charge(requestId, amountFen); }
        catch (BusinessConflict conflict) { return "CONFLICT:" + conflict.getMessage(); }
        System.out.printf("request=%s role=payment transport=dubbo committed=true%n", requestId);
        faults.after(mode);
        return "OK";
    }
}
