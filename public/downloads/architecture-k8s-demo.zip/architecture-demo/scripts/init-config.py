import json
import os
import urllib.parse
import urllib.request

NACOS = os.environ.get("NACOS_URL", "http://127.0.0.1:18848")
CLIENT = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def publish(data_id, content, kind="yaml"):
    data = urllib.parse.urlencode(dict(dataId=data_id, group="ARCH_DEMO", content=content, type=kind)).encode()
    with CLIENT.open(NACOS + "/nacos/v1/cs/configs", data=data, timeout=10) as response:
        assert response.read() == b"true", data_id


if __name__ == "__main__":
    for role in ("orders", "inventory", "payment"):
        publish(role + ".yaml", "demo:\n  message: nacos-" + role + "-v1\n")
    publish("inventory-flow.json", json.dumps([dict(resource="inventory.reserve", grade=1, count=100)]), "json")
    print("Nacos demo configuration initialized (ARCH_DEMO)")
