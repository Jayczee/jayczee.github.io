#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p secrets
chmod 700 secrets
if [ ! -s secrets/mysql_password ]; then
    (umask 077; openssl rand -hex 24 > secrets/mysql_password)
fi
docker compose up -d --wait mysql nacos
python3 scripts/init-config.py
docker compose up -d --build --wait --remove-orphans monolith inventory payment orders gateway
docker compose ps
