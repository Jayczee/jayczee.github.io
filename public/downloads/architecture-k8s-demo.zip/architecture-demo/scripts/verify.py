import concurrent.futures
import json
from pathlib import Path
import socket
import subprocess
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "target" / "experiments"
OUT.mkdir(parents=True, exist_ok=True)
PORTS = dict(monolith=18182, orders=18183, inventory=18184, payment=18185)
STOPPED = set()
RESULTS = {}
CLIENT = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def call(role, path, body=None, timeout=6):
    request = urllib.request.Request(
        f"http://127.0.0.1:{PORTS[role]}{path}",
        data=None if body is None else json.dumps(body).encode(),
        headers={"Content-Type": "application/json"},
    )
    try:
        with CLIENT.open(request, timeout=timeout) as response:
            return response.status, json.load(response)
    except urllib.error.HTTPError as failure:
        return failure.code, json.load(failure)


def ok(role, path, body=None):
    status, result = call(role, path, body)
    assert status in (200, 202), (role, path, status, result)
    return result


def start(role):
    subprocess.run(["docker", "compose", "up", "-d", "--no-deps", "--wait", role], cwd=ROOT, check=True)
    STOPPED.discard(role)
    if role in ("orders", "inventory", "payment"):
        try:
            if call("orders", "/health")[0] == 200:
                wait_rpc()
        except (OSError, urllib.error.URLError):
            pass


def stop(role):
    subprocess.run(["docker", "compose", "stop", role], cwd=ROOT, check=True)
    STOPPED.add(role)


def reset(*roles):
    for role in roles:
        ok(role, "/reset", {})


def payload(request_id, quantity=2):
    return dict(requestId=request_id, userId=7, sku="SKU-A", quantity=quantity, amountFen=quantity * 1000)


def stock(role="inventory"):
    row = ok(role, "/snapshot")["stock"][0]
    return [row["available"], row["locked"], row["sold"]]


def lost_reply(path, request_id):
    ok("inventory", "/fault", {"mode": "after"})
    try:
        call("inventory", path, payload(request_id), timeout=0.5)
        raise AssertionError("expected actual HTTP timeout")
    except (TimeoutError, socket.timeout):
        pass
    assert stock() == [98, 2, 0], "timeout happened before stock commit; repeat under stable network"


def drain_all():
    for attempt in range(40):
        snapshot = ok("orders", "/snapshot")
        pending = [row for row in snapshot["events"] if row["status"] == "PENDING"]
        if not pending:
            assert not [row for row in snapshot["events"] if row["status"] == "FAILED"], snapshot
            return snapshot
        ok("orders", "/drain", {})
    raise AssertionError("drain did not converge")


def verify():
    wait_rpc()
    reset(*PORTS)
    version = subprocess.run(
        ["docker", "compose", "exec", "-T", "orders", "java", "-version"], capture_output=True, text=True, check=True,
    ).stderr
    RESULTS["environment"] = {"java": next(line for line in version.splitlines() if line.startswith("openjdk")), "storage": "MySQL 8 in Docker", "transport": "Spring MVC + Dubbo RPC via Nacos"}

    for role in ("monolith",):
        ok(role, "/fault", {"mode": "rollback"})
        assert call(role, "/orders", payload("rollback"))[0] == 503
        assert ok(role, "/snapshot")["orders"] == []
        assert stock(role) == [100, 0, 0]
        ok(role, "/orders", payload("accepted"))
        ok(role, "/orders", payload("accepted"))
        assert len(ok(role, "/snapshot")["orders"]) == 1
        assert stock(role) == [98, 2, 0]
        ok(role, "/pay", {"requestId": "accepted"})
        ok(role, "/pay", {"requestId": "accepted"})
        assert stock(role) == [98, 0, 2]
        ok(role, "/orders", payload("cancelled"))
        ok(role, "/cancel", {"requestId": "cancelled"})
        ok(role, "/cancel", {"requestId": "cancelled"})
        assert stock(role) == [98, 0, 2]
        assert call(role, "/orders", payload("too-many", 1000))[0] == 409
        assert call(role, "/orders", payload("accepted", 3))[0] == 409
        RESULTS[role] = {"rollbackStock": [100, 0, 0], "afterPayAndCancel": stock(role), "duplicateOrders": 0}

    reset("inventory")
    lost_reply("/unsafe-reserve", "unsafe")
    ok("inventory", "/unsafe-reserve", payload("unsafe"))
    assert stock() == [96, 4, 0]
    RESULTS["unsafeRetry"] = {"afterTimeout": [98, 2, 0], "afterRetry": stock()}

    reset("inventory")
    lost_reply("/reserve", "safe")
    stop("inventory")
    start("inventory")
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
        results = list(executor.map(lambda _: call("inventory", "/reserve", payload("safe")), range(16)))
    assert all(status == 200 for status, _ in results)
    assert stock() == [98, 2, 0]
    assert call("inventory", "/reserve", payload("safe", 3))[0] == 409
    RESULTS["durableIdempotency"] = {"restarted": True, "concurrentRetries": 16, "stock": stock()}

    reset("inventory")
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
        results = list(executor.map(
            lambda index: call("inventory", "/reserve", payload(f"compete-{index}", 6)), range(20)))
    assert sum(status == 200 for status, _ in results) == 16
    assert sum(status == 409 for status, _ in results) == 4
    assert stock() == [4, 96, 0]
    ok("inventory", "/release", payload("late"))
    assert call("inventory", "/reserve", payload("late"))[0] == 409
    RESULTS["concurrentInventory"] = {"accepted": 16, "rejected": 4, "stock": stock(), "lateReserveRejected": True}

    reset("orders", "inventory", "payment")
    ok("orders", "/orders", payload("resume"))
    ok("inventory", "/fault", {"mode": "after"})
    unknown = ok("orders", "/drain", {})
    assert unknown["eventStatus"] == "PENDING", unknown
    assert stock() == [98, 2, 0]
    assert ok("orders", "/orders/resume")["status"] == "PENDING"
    stop("orders")
    stop("inventory")
    start("inventory")
    start("orders")
    snapshot = drain_all()
    assert snapshot["orders"][0]["status"] == "RESERVED"
    assert snapshot["orders"][0]["user_id"] == 7
    assert stock() == [98, 2, 0]
    RESULTS["outboxRecovery"] = {"before": "PENDING", "afterRestart": "RESERVED", "stock": stock(), "userId": 7}

    ok("orders", "/pay", {"requestId": "resume"})
    ok("inventory", "/fault", {"mode": "before"})
    unknown = ok("orders", "/drain", {})
    assert unknown["eventStatus"] == "PENDING"
    assert len(ok("payment", "/snapshot")["payments"]) == 1
    assert stock() == [98, 2, 0]
    assert ok("orders", "/orders/resume")["status"] == "PAY_PENDING"
    stop("payment")
    start("payment")
    drain_all()
    ok("orders", "/pay", {"requestId": "resume"})
    assert ok("orders", "/orders/resume")["status"] == "PAID"
    assert len(ok("payment", "/snapshot")["payments"]) == 1
    assert stock() == [98, 0, 2]
    RESULTS["paymentRecovery"] = {"intermediate": "PAY_PENDING", "payments": 1, "final": "PAID", "stock": stock()}

    ok("orders", "/orders", payload("cancel"))
    drain_all()
    ok("orders", "/cancel", {"requestId": "cancel"})
    drain_all()
    ok("orders", "/cancel", {"requestId": "cancel"})
    assert stock() == [98, 0, 2]

    stop("inventory")
    status, response = call("orders", "/orders", payload("offline"))
    assert status == 202
    assert ok("orders", "/orders/resume")["status"] == "PAID"
    ok("orders", "/drain", {})
    assert ok("orders", "/metrics")["workersMax"] <= 2
    start("inventory")
    snapshot = ok("orders", "/snapshot")
    offline_event = next(row for row in snapshot["events"] if row["request_id"] == "offline")
    assert offline_event["status"] == "PENDING", offline_event
    drain_all()
    assert ok("orders", "/orders/offline")["status"] == "RESERVED"
    RESULTS["isolation"] = {"inventoryProcessStopped": True, "acceptedStatus": status,
                            "historyStatus": "PAID", "maxWorkers": ok("orders", "/metrics")["workersMax"]}

    order_rows = ok("orders", "/snapshot")["orders"]
    reservation_rows = ok("inventory", "/snapshot")["reservations"]
    payment_rows = ok("payment", "/snapshot")["payments"]
    held = sum(row["quantity"] for row in reservation_rows if row["state"] == "HELD")
    sold = sum(row["quantity"] for row in reservation_rows if row["state"] == "CONFIRMED")
    assert stock() == [100-held-sold, held, sold]
    assert held == sum(row["quantity"] for row in order_rows if row["status"] == "RESERVED")
    assert sold == sum(row["quantity"] for row in order_rows if row["status"] == "PAID")
    assert sum(row["amount_fen"] for row in payment_rows) == sum(
        row["amount_fen"] for row in order_rows if row["status"] == "PAID")
    assert not [row for row in ok("orders", "/snapshot")["events"] if row["status"] != "DONE"]
    RESULTS["reconciliation"] = {"orders": len(order_rows), "payments": len(payment_rows),
                                  "stock": stock(), "problems": []}

    reset("orders", "inventory", "payment")
    ok("orders", "/orders", payload("exhausted"))
    stop("inventory")
    for attempt in range(5):
        ok("orders", "/drain", {})
    snapshot = ok("orders", "/snapshot")
    assert snapshot["events"][0]["status"] == "FAILED"
    assert snapshot["events"][0]["attempts"] == 5
    assert snapshot["orders"][0]["status"] == "PENDING"
    start("inventory")
    assert ok("orders", "/drain", {})["processed"] == 0
    RESULTS["retryLimit"] = {"attempts": 5, "event": "FAILED", "order": "PENDING", "requiresManualReview": True}
    reset("orders", "inventory", "payment")
    RESULTS["metrics"] = {role: ok(role, "/metrics") for role in PORTS}


def wait_rpc():
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        try:
            if call("orders", "/rpc-health")[0] == 200:
                return
        except (OSError, urllib.error.URLError):
            pass
        time.sleep(1)
    raise AssertionError("Nacos/Dubbo providers not ready")


try:
    (OUT / "results.json").unlink(missing_ok=True)
    verify()
    (OUT / "results.json").write_text(json.dumps(RESULTS, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(RESULTS, indent=2, ensure_ascii=False))
    print("PASS: MySQL transactions, Dubbo timeout, Nacos rediscovery, restart, concurrency, payment, cancellation, reconciliation")
finally:
    for role in list(STOPPED):
        start(role)
