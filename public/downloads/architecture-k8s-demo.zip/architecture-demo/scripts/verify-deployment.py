import json
from pathlib import Path
import subprocess
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
CLIENT = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def compose(*arguments):
    return subprocess.check_output(["docker", "compose", *arguments], cwd=ROOT, text=True).strip()


def request(port, path, body=None):
    data = None if body is None else json.dumps(body).encode()
    query = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=data,
                                   headers={"Content-Type": "application/json"})
    with CLIENT.open(query, timeout=10) as response:
        return json.load(response)


def wait_rpc():
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        try:
            result = request(18183, "/rpc-health")
            if result == {"inventory": "inventory", "payment": "payment", "transport": "dubbo"}:
                return result
        except (OSError, urllib.error.URLError):
            pass
        time.sleep(1)
    raise AssertionError("Dubbo providers unavailable after deployment")


def verify():
    output = ROOT / "target/experiments/deployment-results.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.unlink(missing_ok=True)
    results = {}
    before = {service: compose("ps", "-q", service) for service in ("orders", "payment", "inventory")}
    assert all(before.values()), before
    inventory_before = request(18184, "/snapshot")
    compose("up", "-d", "--no-deps", "--build", "--force-recreate", "--wait", "inventory")
    after = {service: compose("ps", "-q", service) for service in before}
    assert before["inventory"] != after["inventory"], (before, after)
    assert before["orders"] == after["orders"] and before["payment"] == after["payment"], (before, after)
    probe = wait_rpc()
    assert request(18184, "/snapshot") == inventory_before
    results["inventoryOnlyDeployment"] = {
        "before": before, "after": after, "otherContainersUnchanged": True,
        "inventoryDataPreserved": True, "rpc": probe,
    }

    try:
        compose("stop", "nacos")
        assert not compose("ps", "--status", "running", "-q", "nacos")
        compose("up", "-d", "--no-deps", "--force-recreate", "--wait", "monolith")
        assert request(18182, "/health") == {"role": "monolith", "ready": True}
        request(18182, "/reset", {})
        order = request(18182, "/orders", {"requestId": "monolith-no-nacos", "userId": 7,
                                           "sku": "SKU-A", "quantity": 2})
        assert order["status"] == "RESERVED", order
        paid = request(18182, "/pay", {"requestId": "monolith-no-nacos"})
        assert paid["status"] == "PAID", paid
        snapshot = request(18182, "/snapshot")
        stock = snapshot["stock"][0]
        assert [stock["available"], stock["locked"], stock["sold"]] == [98, 0, 2], snapshot
        assert len(snapshot["payments"]) == 1, snapshot
        results["monolithWithoutNacos"] = {"coldStart": True, "order": paid,
                                           "stock": [98, 0, 2], "payments": 1}
    finally:
        compose("up", "-d", "--wait", "nacos")
    results["restoredRpc"] = wait_rpc()
    results["runningServices"] = sorted(compose("ps", "--status", "running", "--services").splitlines())
    assert results["runningServices"] == sorted(("mysql", "nacos", "monolith", "orders", "inventory", "payment", "gateway"))
    output.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(results, ensure_ascii=False, indent=2))
    print("PASS: independent inventory deployment, unchanged orders/payment, monolith cold start and payment without Nacos")


if __name__ == "__main__":
    verify()
