import hashlib
import io
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
APPS = {
    "monolith-service": ("monolith", "MonolithApplication"),
    "order-service": ("orders", "OrdersApplication"),
    "inventory-service": ("inventory", "InventoryApplication"),
    "payment-service": ("payment", "PaymentApplication"),
    "gateway-service": ("gateway", "GatewayApplication"),
}
PREFIX = "com/jayczee/architecturedemo/"
RESULTS = {}


def verify():
    for module, (package, main_class) in APPS.items():
        jar = ROOT / module / "target" / (module + "-1.0.0.jar")
        with zipfile.ZipFile(jar) as archive:
            manifest = archive.read("META-INF/MANIFEST.MF").decode().replace("\r\n ", "").replace("\n ", "")
            expected = "com.jayczee.architecturedemo." + package + "." + main_class
            assert "Start-Class: " + expected in manifest, (module, manifest)
            classes = set()
            for entry in archive.namelist():
                if entry.endswith(".class"):
                    classes.add(entry.removeprefix("BOOT-INF/classes/"))
                elif entry.startswith("BOOT-INF/lib/") and entry.endswith(".jar"):
                    with zipfile.ZipFile(io.BytesIO(archive.read(entry))) as library:
                        classes.update(name for name in library.namelist() if name.endswith(".class"))
            for other_package, _ in APPS.values():
                if other_package != package:
                    assert not any(name.startswith(PREFIX + other_package + "/") for name in classes), (module, other_package)
            if package == "monolith":
                assert not any(name.startswith(("org/apache/dubbo/", "com/alibaba/nacos/", "com/alibaba/csp/sentinel/", "org/springframework/cloud/")) for name in classes), module
            if package == "orders":
                assert not any(name.endswith(("/InventoryModule.class", "/PaymentModule.class")) for name in classes), module
            config = archive.read("BOOT-INF/classes/application.yml").decode()
            assert "ARCH_ROLE" not in config and "SPRING_PROFILES_ACTIVE" not in config, module
            RESULTS[module] = {"startClass": expected, "sha256": hashlib.sha256(jar.read_bytes()).hexdigest(), "businessCodeIsolated": True}
    for module, package in (("demo-contracts", "api"), ("demo-support", "support")):
        with zipfile.ZipFile(ROOT / module / "target" / (module + "-1.0.0.jar")) as archive:
            classes = [name for name in archive.namelist() if name.endswith(".class")]
            assert classes and all(name.startswith(PREFIX + package + "/") for name in classes), module
            assert not any(name.startswith("BOOT-INF/") for name in archive.namelist()), module
    with zipfile.ZipFile(ROOT / "demo-contracts/target/demo-contracts-1.0.0.jar") as archive:
        assert {name for name in archive.namelist() if name.endswith(".class")} == {
            PREFIX + "api/InventoryRpc.class", PREFIX + "api/PaymentRpc.class"
        }


if __name__ == "__main__":
    output = ROOT / "target/experiments/packaging-results.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.unlink(missing_ok=True)
    verify()
    output.write_text(json.dumps(RESULTS, indent=2) + "\n")
    print(json.dumps(RESULTS, indent=2))
    print("PASS: five independent Boot jars, isolated business code, plain shared libraries, monolith without Cloud")
