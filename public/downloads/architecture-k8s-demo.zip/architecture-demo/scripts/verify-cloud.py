import concurrent.futures
import importlib.util
import json
from pathlib import Path
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
CLIENT = urllib.request.build_opener(urllib.request.ProxyHandler({}))
spec = importlib.util.spec_from_file_location("config_init", ROOT / "scripts" / "init-config.py")
config_init = importlib.util.module_from_spec(spec)
spec.loader.exec_module(config_init)
RESULTS = {}


def request(port, path, body=None):
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=data, headers={"Content-Type": "application/json"})
    try:
        with CLIENT.open(req, timeout=10) as response:
            return response.status, json.load(response)
    except urllib.error.HTTPError as failure:
        return failure.code, json.load(failure)


def ok(port, path, body=None):
    status, response = request(port, path, body)
    assert status in (200, 202), (port, path, status, response)
    return response


def eventually(check, description):
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        try:
            if check():
                return
        except (OSError, urllib.error.URLError):
            pass
        time.sleep(0.5)
    raise AssertionError(description)


def stock():
    row = ok(18184, "/snapshot")["stock"][0]
    return [row["available"], row["locked"], row["sold"]]


def rule(count):
    config_init.publish("inventory-flow.json", json.dumps([dict(resource="inventory.reserve", grade=1, count=count)]), "json")
    eventually(lambda: any(item["resource"] == "inventory.reserve" and item["count"] == count
                          for item in ok(18184, "/metrics")["sentinelRules"]), "Sentinel rule not refreshed")


def place(request_id, quantity=2):
    return ok(18180, "/api/orders", dict(requestId=request_id, userId=7, sku="SKU-A", quantity=quantity))


def verify():
    eventually(lambda: request(18183, "/rpc-health")[0] == 200, "Dubbo providers unavailable")
    with CLIENT.open("http://127.0.0.1:18848/nacos/v1/ns/service/list?pageNo=1&pageSize=100&groupName=ARCH_DEMO") as response:
        names = json.load(response)["doms"]
    assert {"orders", "inventory", "payment", "gateway"}.issubset(names), names
    RESULTS["nacosDiscovery"] = sorted(names)

    config_init.publish("orders.yaml", "demo:\n  message: live-update-v2\n")
    eventually(lambda: ok(18183, "/config")["message"] == "live-update-v2", "Nacos config not refreshed")
    RESULTS["nacosConfig"] = "updated without restarting orders"

    for port in (18183, 18184, 18185):
        ok(port, "/reset", {})
    rule(100)
    place("cloud-pay")
    assert ok(18183, "/drain", {})["status"] == "RESERVED"
    ok(18180, "/api/pay", {"requestId": "cloud-pay"})
    assert ok(18183, "/drain", {})["status"] == "PAID"
    assert ok(18180, "/api/orders/cloud-pay")["status"] == "PAID"
    assert stock() == [98, 0, 2]
    assert len(ok(18185, "/snapshot")["payments"]) == 1
    assert request(18180, "/api/reset", {})[0] == 404
    RESULTS["gatewayDubboPayment"] = {"status": "PAID", "stock": stock(), "payments": 1}

    place("reject-stock", 1000)
    assert ok(18183, "/drain", {})["eventStatus"] == "FAILED"
    assert ok(18180, "/api/orders/reject-stock")["status"] == "REJECTED"
    RESULTS["dubboBusinessRejection"] = "REJECTED"

    rule(0)
    place("sentinel")
    assert ok(18183, "/drain", {})["eventStatus"] == "PENDING"
    assert stock() == [98, 0, 2]
    rule(100)
    assert ok(18183, "/drain", {})["status"] == "RESERVED"
    assert stock() == [96, 2, 2]
    RESULTS["sentinel"] = {"blockedStock": [98, 0, 2], "recoveredStock": stock()}

    place("rpc-timeout")
    ok(18184, "/fault", {"mode": "after"})
    response = ok(18183, "/drain", {})
    assert response["eventStatus"] == "PENDING" and response["attempts"] == 1, response
    assert stock() == [94, 4, 2]
    subprocess.run(["docker", "compose", "restart", "inventory"], cwd=ROOT, check=True)
    eventually(lambda: request(18183, "/rpc-health")[0] == 200, "Dubbo did not rediscover restarted provider")
    assert ok(18183, "/drain", {})["status"] == "RESERVED"
    assert stock() == [94, 4, 2]
    RESULTS["dubboTimeoutRestart"] = {"attemptsAfterTimeout": 1, "stockAfterReplay": stock()}

    for port in (18183, 18184, 18185):
        ok(port, "/reset", {})
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
        list(executor.map(lambda index: place(f"rpc-compete-{index}", 6), range(20)))
    for attempt in range(20):
        ok(18183, "/drain", {})
    rows = ok(18183, "/snapshot")["orders"]
    assert sum(row["status"] == "RESERVED" for row in rows) == 16
    assert sum(row["status"] == "REJECTED" for row in rows) == 4
    assert stock() == [4, 96, 0]
    RESULTS["dubboInventoryContention"] = {"accepted": 16, "rejected": 4, "stock": stock()}

    for port in (18183, 18184, 18185):
        ok(port, "/reset", {})
    place("review-paid")
    assert ok(18183, "/drain", {})["status"] == "RESERVED"
    ok(18180, "/api/pay", {"requestId": "review-paid"})
    assert ok(18183, "/drain", {})["status"] == "PAID"
    RESULTS["reviewOrder"] = ok(18180, "/api/orders/review-paid")


try:
    (ROOT / "target" / "experiments" / "cloud-results.json").unlink(missing_ok=True)
    verify()
    output = ROOT / "target" / "experiments" / "cloud-results.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(RESULTS, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(RESULTS, indent=2, ensure_ascii=False))
    print("PASS: Nacos discovery/config, Gateway, Dubbo RPC, Sentinel, timeout/restart and inventory contention")
finally:
    config_init.publish("orders.yaml", "demo:\n  message: nacos-orders-v1\n")
    rule(100)
